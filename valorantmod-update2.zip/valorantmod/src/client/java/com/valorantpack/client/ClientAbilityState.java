package com.valorantpack.client;

import com.valorantpack.ability.AbilityManager;
import com.valorantpack.network.AbilitySyncPayload;

/**
 * Espelho do estado da Ultimate no cliente. Só é escrito pelo pacote do servidor
 * (e decrementado localmente para a recarga ficar fluida entre pacotes).
 */
public final class ClientAbilityState {
	public static boolean active;
	public static int remaining;
	public static int max = 5;
	/** Recarga restante em ticks (decrementa localmente). */
	public static int cooldownTicks;

	/** Última mudança, para animar o HUD. */
	public static int lastEvent = AbilityManager.EVENT_NONE;
	public static long lastEventTime = -1000;
	/** Contador de ticks do cliente (independente do mundo). */
	public static long clientTicks;

	private ClientAbilityState() {
	}

	public static void apply(AbilitySyncPayload p) {
		active = p.active();
		remaining = p.remaining();
		max = Math.max(1, p.max());
		cooldownTicks = p.cooldownTicks();
		if (p.event() != AbilityManager.EVENT_NONE) {
			lastEvent = p.event();
			lastEventTime = clientTicks;
		}
	}

	public static void tick() {
		clientTicks++;
		if (cooldownTicks > 0) {
			cooldownTicks--;
		}
	}

	public static void reset() {
		active = false;
		remaining = 0;
		cooldownTicks = 0;
		lastEvent = AbilityManager.EVENT_NONE;
		lastEventTime = -1000;
	}
}
