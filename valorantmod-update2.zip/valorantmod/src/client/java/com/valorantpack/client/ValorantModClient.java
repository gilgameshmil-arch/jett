package com.valorantpack.client;

import com.valorantpack.ValorantMod;
import com.valorantpack.network.AbilitySyncPayload;
import com.valorantpack.network.MobilitySyncPayload;
import com.valorantpack.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;

/**
 * Entrypoint do cliente. Tudo aqui é client-only (src/client).
 * Os efeitos 3D de Cloudburst/Tailwind/Updraft são entidades item_display do servidor
 * (renderizadas pelo próprio Minecraft), então não exigem renderizador próprio.
 */
public class ValorantModClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// Facas: renderizadas com o modelo 3D do item "blade_storm_knife", brilho total.
		EntityRendererRegistry.register(ModEntities.BLADE_KNIFE,
				ctx -> new ThrownItemRenderer<>(ctx, 1.6F, true));
		EntityRendererRegistry.register(ModEntities.BLADE_ORBIT,
				ctx -> new ThrownItemRenderer<>(ctx, 1.3F, true));

		ModKeys.init();

		HudElementRegistry.attachElementAfter(VanillaHudElements.HOTBAR,
				ValorantMod.id("blade_storm_hud"), BladeStormHud::render);
		HudElementRegistry.attachElementAfter(VanillaHudElements.HOTBAR,
				ValorantMod.id("mobility_hud"), MobilityHud::render);

		ClientPlayNetworking.registerGlobalReceiver(AbilitySyncPayload.TYPE,
				(payload, context) -> ClientAbilityState.apply(payload));
		ClientPlayNetworking.registerGlobalReceiver(MobilitySyncPayload.TYPE,
				(payload, context) -> ClientMobility.apply(payload));

		ClientTickEvents.START_CLIENT_TICK.register(ClientMobility::preTick);
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			ClientAbilityState.tick();
			ClientMobility.tick();
			ModKeys.poll(client);
		});

		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
			ClientAbilityState.reset();
			ClientMobility.reset();
		});
	}
}
