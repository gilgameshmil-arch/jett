package com.valorantpack.client;

import com.valorantpack.mobility.MobilityManager;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/**
 * HUD da mobilidade: três ícones com tecla e recarga + linhas de velocidade durante o dash.
 * Só usa fill/drawString (mesma abordagem do HUD da Blade Storm).
 */
public final class MobilityHud {
	private static final int SIZE = 22;
	private static final int GAP = 4;
	private static final int[] COLORS = {0xFFB9C9D6, 0xFF4FD8F0, 0xFF3FB6A8};

	private MobilityHud() {
	}

	public static void render(GuiGraphics g, DeltaTracker delta) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.options.hideGui) {
			return;
		}
		float pt = delta.getGameTimeDeltaPartialTick(false);
		speedLines(g, pt);

		KeyMapping[] keys = {ModKeys.CLOUDBURST, ModKeys.TAILWIND, ModKeys.UPDRAFT};
		int x0 = g.guiWidth() / 2 - 91 - 38 - (3 * SIZE + 2 * GAP);
		int y0 = g.guiHeight() - SIZE - 2;
		for (int i = 0; i < 3; i++) {
			int x = x0 + i * (SIZE + GAP);
			int cd = ClientMobility.cooldown[i];
			boolean ready = cd <= 0;
			g.fill(x - 1, y0 - 1, x + SIZE + 1, y0 + SIZE + 1, ready ? 0xCC0A2A33 : 0x99000000);
			g.fillGradient(x, y0, x + SIZE, y0 + SIZE, ready ? COLORS[i] : 0xFF2A3338, ready ? 0xFF16323C : 0xFF171D20);
			if (!ready) {
				float frac = Math.min(1.0f, cd / (float) Math.max(1, ClientMobility.total[i]));
				int h = Math.round(SIZE * frac);
				g.fill(x, y0 + SIZE - h, x + SIZE, y0 + SIZE, 0x88000000);
				String secs = String.valueOf((cd + 19) / 20);
				g.drawString(mc.font, secs, x + SIZE / 2 - mc.font.width(secs) / 2, y0 + SIZE / 2 - 4, 0xFFFFFFFF, true);
			} else {
				String letter = keys[i].getTranslatedKeyMessage().getString();
				g.drawString(mc.font, letter, x + SIZE / 2 - mc.font.width(letter) / 2, y0 + SIZE / 2 - 4, 0xFFFFFFFF, true);
				if (i == MobilityManager.TAILWIND && ClientMobility.dashLeft > 0) {
					g.fill(x, y0 + SIZE - 2, x + SIZE, y0 + SIZE, 0xFFFFFFFF); // marca "dash ativo"
				}
			}
		}
	}

	/** Linhas radiais de velocidade, mais fortes durante o dash e esmaecendo em ~10 ticks depois. */
	private static void speedLines(GuiGraphics g, float partial) {
		double intensity;
		if (ClientMobility.dashLeft > 0) {
			intensity = 1.0;
		} else {
			intensity = Math.max(0.0, 1.0 - (ClientMobility.sinceDash + partial) / 10.0);
		}
		if (intensity <= 0.01) {
			return;
		}
		int w = g.guiWidth();
		int h = g.guiHeight();
		double cx = w / 2.0;
		double cy = h / 2.0;
		double maxR = Math.hypot(cx, cy);
		double t = ClientMobility.clientTicks + partial;
		for (int i = 0; i < 34; i++) {
			double ang = i * 2.399963 + Math.floor(t * 0.5 + i) * 1.7;
			double r0 = maxR * (0.50 + 0.38 * frac(i * 0.618 + Math.floor(t * 0.5)));
			double len = maxR * (0.10 + 0.16 * frac(i * 0.331));
			double ca = Math.cos(ang);
			double sa = Math.sin(ang);
			int steps = 9;
			for (int s = 0; s < steps; s++) {
				double r = r0 + len * s / steps;
				int px = (int) (cx + ca * r);
				int py = (int) (cy + sa * r);
				if (px < 0 || py < 0 || px >= w || py >= h) {
					continue;
				}
				double a = intensity * (0.15 + 0.5 * s / steps);
				int alpha = (int) Math.max(0, Math.min(255, a * 255));
				g.fill(px, py, px + 2, py + 2, (alpha << 24) | 0xE6F8FF);
			}
		}
	}

	private static double frac(double v) {
		return v - Math.floor(v);
	}
}
