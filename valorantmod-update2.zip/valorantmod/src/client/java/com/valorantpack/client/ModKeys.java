package com.valorantpack.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.valorantpack.ValorantMod;
import com.valorantpack.mobility.MobilityManager;
import com.valorantpack.network.AbilityActionPayload;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

/**
 * Teclas configuráveis (Opções > Controles > "Valorant Pack").
 * Padrões: X ativa a Ultimate, R lança uma faca, V lança todas.
 * Mobilidade: G = Cloudburst, C = Tailwind (dash), Z = Updraft.
 * (E e Q do Valorant colidem com Inventário/Largar item do Minecraft; troque nos Controles se quiser.)
 */
public final class ModKeys {
	private static final KeyMapping.Category CATEGORY =
			KeyMapping.Category.register(ValorantMod.id("abilities"));

	public static final KeyMapping ACTIVATE = KeyBindingHelper.registerKeyBinding(
			new KeyMapping("key.valorantmod.activate_ultimate", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_X, CATEGORY));
	public static final KeyMapping THROW_ONE = KeyBindingHelper.registerKeyBinding(
			new KeyMapping("key.valorantmod.throw_knife", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, CATEGORY));
	public static final KeyMapping THROW_VOLLEY = KeyBindingHelper.registerKeyBinding(
			new KeyMapping("key.valorantmod.throw_volley", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, CATEGORY));

	public static final KeyMapping CLOUDBURST = KeyBindingHelper.registerKeyBinding(
			new KeyMapping("key.valorantmod.cloudburst", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, CATEGORY));
	public static final KeyMapping TAILWIND = KeyBindingHelper.registerKeyBinding(
			new KeyMapping("key.valorantmod.tailwind", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, CATEGORY));
	public static final KeyMapping UPDRAFT = KeyBindingHelper.registerKeyBinding(
			new KeyMapping("key.valorantmod.updraft", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_Z, CATEGORY));

	private ModKeys() {
	}

	public static void init() {
		// Força o carregamento da classe (registra as teclas).
	}

	/** Chamado todo tick do cliente: envia pedidos ao servidor, que valida tudo. */
	public static void poll(Minecraft mc) {
		if (mc.player == null) {
			return;
		}
		while (ACTIVATE.consumeClick()) {
			send(AbilityActionPayload.ACTIVATE);
		}
		while (THROW_ONE.consumeClick()) {
			send(AbilityActionPayload.THROW_ONE);
		}
		while (THROW_VOLLEY.consumeClick()) {
			send(AbilityActionPayload.THROW_VOLLEY);
		}
		while (CLOUDBURST.consumeClick()) {
			ClientMobility.tryCast(mc, MobilityManager.CLOUDBURST);
		}
		while (TAILWIND.consumeClick()) {
			ClientMobility.tryCast(mc, MobilityManager.TAILWIND);
		}
		while (UPDRAFT.consumeClick()) {
			ClientMobility.tryCast(mc, MobilityManager.UPDRAFT);
		}
	}

	private static void send(int action) {
		ClientPlayNetworking.send(new AbilityActionPayload(action));
	}
}
