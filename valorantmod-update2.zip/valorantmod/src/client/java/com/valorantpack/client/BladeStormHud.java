package com.valorantpack.client;

import com.valorantpack.ability.AbilityManager;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * HUD da Blade Storm: uma "lâmina" por faca disponível, título, recarga e
 * flashes ao recuperar/lançar. Usa só fill/fillGradient/drawString para
 * minimizar dependência de APIs de renderização que mudam entre versões.
 */
public final class BladeStormHud {
	private static final int CELL_W = 12;
	private static final int CELL_H = 22;
	private static final int GAP = 5;

	private BladeStormHud() {
	}

	public static void render(GuiGraphics g, DeltaTracker delta) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.options.hideGui) {
			return;
		}
		int max = ClientAbilityState.max;
		boolean active = ClientAbilityState.active;
		int cd = ClientAbilityState.cooldownTicks;
		if (!active && cd <= 0) {
			return; // nada a mostrar
		}

		float pt = delta.getGameTimeDeltaPartialTick(false);
		double t = ClientAbilityState.clientTicks + pt;
		double since = t - ClientAbilityState.lastEventTime;

		int total = max * CELL_W + (max - 1) * GAP;
		int x0 = g.guiWidth() / 2 - total / 2;
		int y0 = g.guiHeight() - 68;

		if (active) {
			boolean recovered = ClientAbilityState.lastEvent == AbilityManager.EVENT_RECOVERED
					|| ClientAbilityState.lastEvent == AbilityManager.EVENT_READY;
			double flash = recovered ? Math.max(0.0, 1.0 - since / 14.0) : 0.0;

			// título + contagem
			Component title = Component.translatable("hud.valorantmod.title");
			String count = ClientAbilityState.remaining + "/" + max;
			g.drawString(mc.font, title, g.guiWidth() / 2 - mc.font.width(title) / 2, y0 - 22, 0xFF7CF3FF, true);
			g.drawString(mc.font, count, g.guiWidth() / 2 - mc.font.width(count) / 2, y0 - 11, 0xFFFFFFFF, true);

			for (int i = 0; i < max; i++) {
				int x = x0 + i * (CELL_W + GAP);
				boolean avail = i < ClientAbilityState.remaining;
				double pulse = 0.5 + 0.5 * Math.sin(t * 0.25 + i * 0.9);
				// moldura
				g.fill(x - 1, y0 - 1, x + CELL_W + 1, y0 + CELL_H + 1, avail ? 0xCC0A2A33 : 0x88000000);
				if (avail) {
					int top = lerpColor(0xFF9FFAFF, 0xFFFFFFFF, (float) Math.max(flash, pulse * 0.35));
					g.fillGradient(x, y0, x + CELL_W, y0 + CELL_H, top, 0xFF1AA6C4);
				} else {
					g.fill(x, y0, x + CELL_W, y0 + CELL_H, 0x55222B30);
				}
			}

			if (flash > 0.0) {
				int a = (int) (flash * 90);
				g.fill(x0 - 6, y0 - 4, x0 + total + 6, y0 + CELL_H + 4, (a << 24) | 0x00BFFFFF);
			}
		} else {
			// recarga
			int secs = (cd + 19) / 20;
			Component msg = Component.translatable("hud.valorantmod.recharging", secs);
			g.drawString(mc.font, msg, g.guiWidth() / 2 - mc.font.width(msg) / 2, y0 + 6, 0xFF9AA7AD, true);
		}
	}

	private static int lerpColor(int a, int b, float f) {
		f = Math.max(0f, Math.min(1f, f));
		int r = (int) (((a >> 16) & 0xFF) * (1 - f) + ((b >> 16) & 0xFF) * f);
		int gr = (int) (((a >> 8) & 0xFF) * (1 - f) + ((b >> 8) & 0xFF) * f);
		int bl = (int) ((a & 0xFF) * (1 - f) + (b & 0xFF) * f);
		return 0xFF000000 | (r << 16) | (gr << 8) | bl;
	}
}
