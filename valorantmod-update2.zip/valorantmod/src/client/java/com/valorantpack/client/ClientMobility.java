package com.valorantpack.client;

import com.valorantpack.config.ModConfig;
import com.valorantpack.mobility.MobilityManager;
import com.valorantpack.network.MobilityActionPayload;
import com.valorantpack.network.MobilitySyncPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/**
 * Lado do cliente da mobilidade.
 *
 * O movimento (dash e impulso) é aplicado AQUI, no mesmo tick da tecla: o servidor confia na posição do
 * cliente, como no movimento vanilla, então não há atraso de ida e volta. O servidor só valida recarga e
 * cria os efeitos visíveis a todos; se recusar (DENIED), o dash local é cancelado.
 *
 * Dash: velocidade horizontal imposta a cada tick por {@code dashTicks} ticks, com leve desaceleração no
 * fim, gravidade quase zerada no ar (dash "reto") e uma sobra de velocidade ao terminar.
 * Valores (dashSpeed, dashTicks, updraftVelocity) vêm da config deste cliente.
 */
public final class ClientMobility {
	public static final int[] cooldown = new int[3];
	public static final int[] total = {1, 1, 1};

	public static int dashLeft;
	public static int dashTotal = 1;
	/** Ticks desde o fim do dash (para esmaecer as linhas de velocidade). */
	public static int sinceDash = 100;
	public static long clientTicks;

	private static double dashX;
	private static double dashZ;

	private ClientMobility() {
	}

	public static void apply(MobilitySyncPayload p) {
		int a = p.ability();
		if (a < 0 || a > 2) {
			return;
		}
		cooldown[a] = Math.max(0, p.cooldownTicks());
		if (p.event() == MobilityManager.EVENT_USED) {
			total[a] = Math.max(1, p.cooldownTicks());
		} else if (p.event() == MobilityManager.EVENT_DENIED && a == MobilityManager.TAILWIND) {
			dashLeft = 0;
		}
	}

	public static void reset() {
		for (int i = 0; i < 3; i++) {
			cooldown[i] = 0;
		}
		dashLeft = 0;
		sinceDash = 100;
	}

	/** END_CLIENT_TICK: contadores. */
	public static void tick() {
		clientTicks++;
		for (int i = 0; i < 3; i++) {
			if (cooldown[i] > 0) {
				cooldown[i]--;
			}
		}
		if (dashLeft <= 0) {
			sinceDash++;
		}
	}

	/** START_CLIENT_TICK: impõe a velocidade do dash antes de o jogador se mover neste tick. */
	public static void preTick(Minecraft mc) {
		LocalPlayer player = mc.player;
		if (player == null || dashLeft <= 0) {
			return;
		}
		if (player.isSpectator() || player.isDeadOrDying()) {
			dashLeft = 0;
			return;
		}
		ModConfig cfg = ModConfig.get();
		double prog = 1.0 - (double) dashLeft / Math.max(1, dashTotal);       // 0 -> 1
		double speed = cfg.dashSpeed * (1.0 - 0.30 * prog * prog);            // desacelera de leve no fim
		Vec3 v = player.getDeltaMovement();
		double y = player.onGround() ? v.y : Math.max(v.y * 0.5, -0.04);     // quase sem queda durante o dash
		player.setDeltaMovement(dashX * speed, y, dashZ * speed);
		dashLeft--;
		if (dashLeft == 0) {
			sinceDash = 0;
			Vec3 after = player.getDeltaMovement();
			player.setDeltaMovement(after.x * 0.35, after.y, after.z * 0.35); // sobra de velocidade, sem "freada seca"
		}
	}

	public static void tryCast(Minecraft mc, int ability) {
		LocalPlayer player = mc.player;
		if (player == null || mc.screen != null || player.isSpectator() || cooldown[ability] > 0) {
			return;
		}
		ModConfig cfg = ModConfig.get();
		float dx = 0.0f;
		float dz = 0.0f;
		int cd;
		switch (ability) {
			case MobilityManager.CLOUDBURST -> cd = cfg.cloudburstCooldownSeconds * 20;
			case MobilityManager.TAILWIND -> {
				cd = cfg.tailwindCooldownSeconds * 20;
				Vec3 dir = dashDirection(mc, player);
				dashX = dir.x;
				dashZ = dir.z;
				dashTotal = cfg.dashTicks;
				dashLeft = cfg.dashTicks;
				dx = (float) dir.x;
				dz = (float) dir.z;
			}
			default -> {
				cd = cfg.updraftCooldownSeconds * 20;
				Vec3 v = player.getDeltaMovement();
				player.setDeltaMovement(v.x, cfg.updraftVelocity, v.z);
			}
		}
		// recarga prevista; o servidor corrige no pacote de sincronização
		cooldown[ability] = cd;
		total[ability] = Math.max(1, cd);
		ClientPlayNetworking.send(new MobilityActionPayload(ability, dx, dz));
	}

	/** Direção do dash segundo as teclas de movimento (W/A/S/D) relativas à câmera; sem tecla = para frente. */
	private static Vec3 dashDirection(Minecraft mc, LocalPlayer player) {
		double yaw = Math.toRadians(player.getYRot());
		double fx = -Math.sin(yaw);
		double fz = Math.cos(yaw);
		double lx = Math.cos(yaw);   // esquerda
		double lz = Math.sin(yaw);
		double fwd = (mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0);
		double left = (mc.options.keyLeft.isDown() ? 1 : 0) - (mc.options.keyRight.isDown() ? 1 : 0);
		if (fwd == 0 && left == 0) {
			fwd = 1;
		}
		double x = fx * fwd + lx * left;
		double z = fz * fwd + lz * left;
		double len = Math.sqrt(x * x + z * z);
		return len < 1.0E-6 ? new Vec3(fx, 0, fz) : new Vec3(x / len, 0, z / len);
	}
}
