package com.valorantpack.ability;

import com.valorantpack.config.ModConfig;
import com.valorantpack.entity.BladeKnifeEntity;
import com.valorantpack.entity.BladeOrbitEntity;
import com.valorantpack.fx.Fx;
import com.valorantpack.network.AbilityActionPayload;
import com.valorantpack.network.AbilitySyncPayload;
import com.valorantpack.registry.ModEntities;
import com.valorantpack.registry.ModItems;
import com.valorantpack.registry.ModSounds;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Coração da mecânica da Blade Storm. Toda a lógica é autoritativa no servidor;
 * o cliente só pede ações (AbilityActionPayload) e recebe o estado (AbilitySyncPayload).
 *
 * Fluxo:
 *   ativar  -> estado criado, facas materializam uma a uma (escalonadas) em órbita
 *   lançar  -> consome a faca de maior índice, mira convergente no ponto da mira
 *   abater  -> AFTER_DEATH com faca como causa direta restaura todas as facas
 *   fim     -> sem facas e nenhuma em voo (ou tempo máximo): recarga começa
 *
 * Para futuras habilidades, crie uma classe análoga (ou extraia uma interface Ability)
 * e registre o tick/eventos em init() — o HUD e a rede já são genéricos por payload.
 */
public final class AbilityManager {
	public static final int EVENT_NONE = 0;
	public static final int EVENT_ACTIVATED = 1;
	public static final int EVENT_THROWN = 2;
	public static final int EVENT_RECOVERED = 3;
	public static final int EVENT_ENDED = 4;
	public static final int EVENT_READY = 5;

	public static final int APPEAR_STAGGER_TICKS = 4;
	private static final double MAX_AIM_DISTANCE = 80.0;

	private static final Map<UUID, BladeStormState> STATES = new HashMap<>();
	/** Tick do servidor em que a recarga termina (sobrevive a desconexões enquanto o servidor roda). */
	private static final Map<UUID, Integer> COOLDOWN_UNTIL = new HashMap<>();

	private AbilityManager() {
	}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(AbilityManager::tick);
		ServerLivingEntityEvents.AFTER_DEATH.register(AbilityManager::onDeath);
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
			BladeStormState st = STATES.remove(handler.getPlayer().getUUID());
			if (st != null) {
				discardOrbits(st);
			}
		});
	}

	// =========================================================================== consultas

	public static boolean isActive(Entity entity) {
		BladeStormState st = STATES.get(entity.getUUID());
		return st != null && st.active;
	}

	private static BladeStormState state(ServerPlayer player) {
		return STATES.computeIfAbsent(player.getUUID(), BladeStormState::new);
	}

	private static int now(ServerPlayer player) {
		MinecraftServer server = player.level().getServer();
		return server != null ? server.getTickCount() : 0;
	}

	private static boolean hasItem(ServerPlayer player) {
		var inv = player.getInventory();
		for (int i = 0; i < inv.getContainerSize(); i++) {
			if (inv.getItem(i).is(ModItems.BLADE_STORM)) {
				return true;
			}
		}
		return false;
	}

	// =========================================================================== entradas

	/** Botão direito com o item na mão. */
	public static void onItemUse(ServerPlayer player) {
		BladeStormState st = state(player);
		if (!st.active) {
			activate(player, st, false);
		} else {
			throwOne(player, st, false);
		}
	}

	/** Teclas configuráveis (pacote C2S). */
	public static void handleAction(ServerPlayer player, int action) {
		if (!player.isAlive() || player.isSpectator()) {
			return;
		}
		BladeStormState st = state(player);
		switch (action) {
			case AbilityActionPayload.ACTIVATE -> {
				if (!st.active) {
					activate(player, st, true);
				}
			}
			case AbilityActionPayload.THROW_ONE -> {
				if (st.active) {
					throwOne(player, st, false);
				}
			}
			case AbilityActionPayload.THROW_VOLLEY -> {
				if (st.active && st.remaining > 0 && st.volleyLeft == 0) {
					st.volleyLeft = st.remaining;
					st.nextVolleyTick = now(player);
				}
			}
			default -> {
			}
		}
	}

	// =========================================================================== ativação

	private static void activate(ServerPlayer player, BladeStormState st, boolean fromKey) {
		ModConfig cfg = ModConfig.get();
		if (!(player.level() instanceof ServerLevel level)) {
			return;
		}
		int now = now(player);

		if (fromKey && cfg.keyRequiresItem && !hasItem(player)) {
			player.displayClientMessage(Component.translatable("message.valorantmod.need_item"), true);
			return;
		}
		int until = COOLDOWN_UNTIL.getOrDefault(player.getUUID(), 0);
		if (now < until) {
			int secs = (until - now + 19) / 20;
			player.displayClientMessage(Component.translatable("message.valorantmod.cooldown", secs), true);
			return;
		}

		st.reset(cfg.knifeCount, now);

		Vec3 pos = player.position();
		Fx.sound(level, pos, ModSounds.ACTIVATE, 1.0f, 1.0f);
		Fx.sound(level, pos, ModSounds.WIND, 1.0f, 1.0f);
		Fx.activation(level, player);
		sync(player, st, EVENT_ACTIVATED, now);
	}

	// =========================================================================== tick

	private static void tick(MinecraftServer server) {
		int now = server.getTickCount();
		Iterator<Map.Entry<UUID, BladeStormState>> it = STATES.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<UUID, BladeStormState> entry = it.next();
			BladeStormState st = entry.getValue();
			ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
			if (player == null) {
				discardOrbits(st);
				it.remove();
				continue;
			}
			if (!st.active) {
				continue;
			}
			if (!player.isAlive() || player.isSpectator()) {
				end(player, st, now, true);
				continue;
			}
			tickActive(player, st, now);
		}
	}

	private static void tickActive(ServerPlayer player, BladeStormState st, int now) {
		ModConfig cfg = ModConfig.get();
		if (!(player.level() instanceof ServerLevel level)) {
			return;
		}

		// 1) Materializa (ou recria, se sumiram) as facas em órbita, uma a uma.
		boolean allPresent = true;
		for (int i = 0; i < st.max; i++) {
			if (!st.slotAvailable[i]) {
				continue;
			}
			BladeOrbitEntity e = st.orbit[i];
			boolean missing = e == null || e.isRemoved() || e.level() != level;
			if (missing) {
				if (now >= st.spawnAt[i]) {
					spawnOrbit(level, player, st, i);
				} else {
					allPresent = false;
				}
			}
		}
		if (st.pendingReadyFx && allPresent && st.remaining == st.max) {
			st.pendingReadyFx = false;
			Fx.ready(level, player);
			Fx.sound(level, player.position(), ModSounds.READY, 1.0f, 1.0f);
			sync(player, st, EVENT_READY, now);
		}

		// 2) Rajada ("lançar todas as restantes").
		if (st.volleyLeft > 0) {
			if (st.remaining <= 0) {
				st.volleyLeft = 0;
			} else if (now >= st.nextVolleyTick) {
				if (throwKnife(player, st, now, cfg.volleySpreadDegrees, true)) {
					st.volleyLeft--;
					st.nextVolleyTick = now + cfg.volleyIntervalTicks;
				}
			}
		}

		// 3) Limite de duração opcional.
		if (cfg.maxActiveSeconds > 0 && now - st.activatedTick > cfg.maxActiveSeconds * 20) {
			end(player, st, now, true);
			return;
		}

		// 4) Fim natural: sem facas e nada mais em voo (ou espera máxima esgotada).
		if (st.remaining == 0) {
			int sinceLast = now - st.lastThrowTick;
			int hardCap = Math.max(cfg.recoveryGraceTicks, cfg.knifeMaxLifeTicks + 5);
			if ((st.inFlight <= 0 && sinceLast >= 10) || sinceLast >= hardCap) {
				end(player, st, now, true);
			}
		}
	}

	private static void spawnOrbit(ServerLevel level, ServerPlayer player, BladeStormState st, int slot) {
		BladeOrbitEntity e = new BladeOrbitEntity(ModEntities.BLADE_ORBIT, level);
		e.setup(player, slot, st.max);
		Vec3 p = com.valorantpack.entity.OrbitMath.position(player, slot, st.max, level.getGameTime());
		e.setPos(p.x, p.y, p.z);
		level.addFreshEntity(e);
		st.orbit[slot] = e;

		Fx.knifeAppear(level, p);
		Fx.sound(level, p, ModSounds.KNIFE_APPEAR, 0.6f, 0.9f + 0.1f * slot);
	}

	// =========================================================================== lançamento

	private static void throwOne(ServerPlayer player, BladeStormState st, boolean ignoreInterval) {
		throwKnife(player, st, now(player), 0.0, ignoreInterval);
	}

	/** @return true se uma faca foi lançada */
	private static boolean throwKnife(ServerPlayer player, BladeStormState st, int now, double spreadDeg, boolean ignoreInterval) {
		ModConfig cfg = ModConfig.get();
		if (!st.active || st.remaining <= 0 || !(player.level() instanceof ServerLevel level)) {
			return false;
		}
		if (!ignoreInterval && now - st.lastThrowTick < cfg.throwIntervalTicks) {
			return false;
		}

		// Consome do maior índice para o menor, apenas facas já materializadas.
		int slot = -1;
		for (int i = st.max - 1; i >= 0; i--) {
			BladeOrbitEntity e = st.orbit[i];
			if (st.slotAvailable[i] && e != null && !e.isRemoved()) {
				slot = i;
				break;
			}
		}
		if (slot < 0) {
			return false;
		}
		BladeOrbitEntity orb = st.orbit[slot];

		Vec3 eye = player.getEyePosition();
		Vec3 look = player.getLookAngle();
		Vec3 start = orb.level() == level ? orb.position() : eye;
		// Não deixa a faca nascer atrás de uma parede.
		BlockHitResult wall = level.clip(new ClipContext(eye, start, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
		if (wall.getType() != HitResult.Type.MISS) {
			start = eye.add(look.scale(0.5));
		}

		Vec3 target = aimPoint(level, player, eye, look);
		Vec3 dir = target.subtract(start);
		if (dir.lengthSqr() < 1.0) {
			dir = look;
		}
		dir = applySpread(dir.normalize(), spreadDeg, level);

		BladeKnifeEntity knife = new BladeKnifeEntity(ModEntities.BLADE_KNIFE, level);
		knife.setOwner(player);
		knife.setPos(start.x, start.y, start.z);
		knife.setDeltaMovement(dir.scale(cfg.knifeSpeed));
		float yaw = (float) Math.toDegrees(Math.atan2(dir.x, dir.z));
		float pitch = (float) Math.toDegrees(Math.atan2(dir.y, Math.sqrt(dir.x * dir.x + dir.z * dir.z)));
		knife.setYRot(yaw);
		knife.setXRot(pitch);
		knife.yRotO = yaw;
		knife.xRotO = pitch;
		level.addFreshEntity(knife);

		st.slotAvailable[slot] = false;
		st.orbit[slot] = null;
		orb.discard();
		st.remaining--;
		st.inFlight++;
		st.lastThrowTick = now;

		Fx.knifeThrow(level, start, dir);
		Fx.sound(level, start, ModSounds.THROW, 0.9f, 0.9f + level.random.nextFloat() * 0.3f);
		sync(player, st, EVENT_THROWN, now);
		return true;
	}

	/**
	 * Ponto para onde a faca deve convergir: o primeiro bloco ou entidade viva na linha da mira.
	 * Como a faca nasce na órbita (deslocada da mira), mirar nesse ponto — e não "reto" —
	 * é o que faz a faca acertar onde o jogador está olhando.
	 */
	private static Vec3 aimPoint(ServerLevel level, ServerPlayer player, Vec3 eye, Vec3 look) {
		Vec3 end = eye.add(look.scale(MAX_AIM_DISTANCE));
		BlockHitResult block = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
		Vec3 target = block.getType() == HitResult.Type.MISS ? end : block.getLocation();
		double best = eye.distanceToSqr(target);

		AABB box = player.getBoundingBox().expandTowards(look.scale(MAX_AIM_DISTANCE)).inflate(1.0);
		for (Entity e : level.getEntities(player, box,
				x -> x instanceof LivingEntity && x.isAlive() && !x.isSpectator() && x.isPickable())) {
			Optional<Vec3> hit = e.getBoundingBox().inflate(0.3).clip(eye, target);
			if (hit.isPresent()) {
				double d = eye.distanceToSqr(hit.get());
				if (d < best) {
					best = d;
					target = hit.get();
				}
			}
		}
		return target;
	}

	private static Vec3 applySpread(Vec3 dir, double spreadDeg, ServerLevel level) {
		if (spreadDeg <= 0.0) {
			return dir;
		}
		double t = Math.tan(Math.toRadians(spreadDeg));
		Vec3 right = dir.cross(new Vec3(0, 1, 0));
		if (right.lengthSqr() < 1.0E-6) {
			right = new Vec3(1, 0, 0);
		}
		right = right.normalize();
		Vec3 up = right.cross(dir).normalize();
		double rx = (level.random.nextDouble() * 2.0 - 1.0) * t;
		double ry = (level.random.nextDouble() * 2.0 - 1.0) * t;
		return dir.add(right.scale(rx)).add(up.scale(ry)).normalize();
	}

	// =========================================================================== eliminação e recuperação

	private static void onDeath(LivingEntity victim, DamageSource source) {
		if (victim instanceof ServerPlayer dead) {
			BladeStormState st = STATES.get(dead.getUUID());
			if (st != null && st.active) {
				end(dead, st, now(dead), true);
			}
		}
		if (source.getDirectEntity() instanceof BladeKnifeEntity
				&& source.getEntity() instanceof ServerPlayer killer
				&& killer != victim) {
			onKnifeKill(killer);
		}
	}

	private static void onKnifeKill(ServerPlayer killer) {
		if (!ModConfig.get().recoverOnKill) {
			return;
		}
		BladeStormState st = STATES.get(killer.getUUID());
		if (st == null || !st.active || !(killer.level() instanceof ServerLevel level)) {
			return;
		}
		int now = now(killer);

		int k = 0;
		for (int i = 0; i < st.max; i++) {
			if (!st.slotAvailable[i]) {
				st.slotAvailable[i] = true;
				st.orbit[i] = null;
				st.spawnAt[i] = now + 4 + k * 3;
				k++;
			}
		}
		st.remaining = st.max;
		st.volleyLeft = 0;
		st.pendingReadyFx = true;

		Fx.refresh(level, killer);
		Fx.sound(level, killer.position(), ModSounds.REFRESH, 1.0f, 1.0f);
		sync(killer, st, EVENT_RECOVERED, now);
	}

	/** Chamado pela faca ao terminar (acertou, expirou). */
	public static void onKnifeResolved(ServerPlayer owner) {
		BladeStormState st = STATES.get(owner.getUUID());
		if (st != null) {
			st.inFlight = Math.max(0, st.inFlight - 1);
		}
	}

	// =========================================================================== fim

	private static void end(ServerPlayer player, BladeStormState st, int now, boolean applyCooldown) {
		boolean wasActive = st.active;
		st.active = false;
		st.remaining = 0;
		st.volleyLeft = 0;
		st.pendingReadyFx = false;
		discardOrbits(st);
		if (!wasActive) {
			return;
		}
		if (applyCooldown) {
			COOLDOWN_UNTIL.put(player.getUUID(), now + ModConfig.get().ultimateCooldownSeconds * 20);
		}
		if (player.level() instanceof ServerLevel level) {
			Fx.end(level, player);
			Fx.sound(level, player.position(), ModSounds.END, 0.8f, 1.0f);
		}
		sync(player, st, EVENT_ENDED, now);
	}

	private static void discardOrbits(BladeStormState st) {
		for (int i = 0; i < st.orbit.length; i++) {
			BladeOrbitEntity e = st.orbit[i];
			if (e != null && !e.isRemoved()) {
				e.discard();
			}
			st.orbit[i] = null;
		}
	}

	// =========================================================================== rede

	private static void sync(ServerPlayer player, BladeStormState st, int event, int now) {
		int cd = Math.max(0, COOLDOWN_UNTIL.getOrDefault(player.getUUID(), 0) - now);
		ServerPlayNetworking.send(player, new AbilitySyncPayload(st.active, st.remaining, st.max, cd, event));
	}
}
