package com.valorantpack.ability;

import com.valorantpack.entity.BladeOrbitEntity;

import java.util.UUID;

/**
 * Estado da Blade Storm de um jogador (apenas no servidor).
 *
 * Invariante: {@code remaining} == número de {@code slotAvailable[i] == true}.
 * Slots são consumidos do maior índice para o menor, por isso o HUD mostra
 * "disponível" para i &lt; remaining.
 */
public final class BladeStormState {
	public final UUID playerId;

	public boolean active;
	public int max;
	public int remaining;

	/** Facas ainda não arremessadas. */
	public boolean[] slotAvailable = new boolean[0];
	/** Entidade visual em órbita de cada slot (null enquanto não materializou). */
	public BladeOrbitEntity[] orbit = new BladeOrbitEntity[0];
	/** Tick do servidor a partir do qual cada slot pode materializar. */
	public int[] spawnAt = new int[0];

	public int activatedTick;
	public int lastThrowTick = -1000;
	/** Facas deste jogador ainda em voo. */
	public int inFlight;

	/** Lançamento "todas de uma vez" em andamento. */
	public int volleyLeft;
	public int nextVolleyTick;

	/** Dispara o efeito de "tudo pronto" quando todas as facas voltarem a materializar. */
	public boolean pendingReadyFx;

	public BladeStormState(UUID playerId) {
		this.playerId = playerId;
	}

	public void reset(int max, int now) {
		this.active = true;
		this.max = max;
		this.remaining = max;
		this.slotAvailable = new boolean[max];
		this.orbit = new BladeOrbitEntity[max];
		this.spawnAt = new int[max];
		for (int i = 0; i < max; i++) {
			slotAvailable[i] = true;
			spawnAt[i] = now + 6 + i * AbilityManager.APPEAR_STAGGER_TICKS;
		}
		this.activatedTick = now;
		this.lastThrowTick = -1000;
		this.inFlight = 0;
		this.volleyLeft = 0;
		this.pendingReadyFx = false;
	}
}
