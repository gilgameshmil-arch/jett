package com.valorantpack.entity;

import com.valorantpack.ability.AbilityManager;
import com.valorantpack.fx.Fx;
import com.valorantpack.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/**
 * Faca de energia flutuando ao redor do jogador. Puramente visual.
 *
 * A posição NÃO é sincronizada pela rede a cada tick (updateInterval enorme em ModEntities);
 * servidor e cliente calculam a mesma órbita a partir do dono, o que dá movimento
 * suave sem custo de banda. O dono, o slot e o total são enviados uma vez via SynchedEntityData.
 */
public class BladeOrbitEntity extends ThrowableItemProjectile {
	private static final EntityDataAccessor<Integer> OWNER_ID = SynchedEntityData.defineId(BladeOrbitEntity.class, EntityDataSerializers.INT);
	private static final EntityDataAccessor<Integer> SLOT = SynchedEntityData.defineId(BladeOrbitEntity.class, EntityDataSerializers.INT);
	private static final EntityDataAccessor<Integer> MAX = SynchedEntityData.defineId(BladeOrbitEntity.class, EntityDataSerializers.INT);

	public BladeOrbitEntity(EntityType<? extends BladeOrbitEntity> type, Level level) {
		super(type, level);
		this.noPhysics = true;
		this.setNoGravity(true);
	}

	public void setup(Entity owner, int slot, int max) {
		this.entityData.set(OWNER_ID, owner.getId());
		this.entityData.set(SLOT, slot);
		this.entityData.set(MAX, max);
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(OWNER_ID, -1);
		builder.define(SLOT, 0);
		builder.define(MAX, 5);
	}

	@Override
	protected Item getDefaultItem() {
		return ModItems.BLADE_STORM_KNIFE;
	}

	@Override
	protected double getDefaultGravity() {
		return 0.0;
	}

	@Override
	public boolean isPickable() {
		return false;
	}

	@Override
	public boolean canBeHitByProjectile() {
		return false;
	}

	@Override
	public void tick() {
		// Não chama super.tick(): esta entidade nunca se move por física nem colide.
		this.baseTick();

		int ownerId = this.entityData.get(OWNER_ID);
		if (ownerId < 0) {
			return; // dados ainda não chegaram ao cliente
		}
		Entity owner = this.level().getEntity(ownerId);
		boolean client = this.level().isClientSide();
		if (owner == null || !owner.isAlive()) {
			if (!client) {
				this.discard();
			}
			return;
		}
		if (!client && !AbilityManager.isActive(owner)) {
			this.discard();
			return;
		}

		int slot = this.entityData.get(SLOT);
		int max = this.entityData.get(MAX);
		double time = this.level().getGameTime();
		Vec3 p = OrbitMath.position(owner, slot, max, time);
		this.setPos(p.x, p.y, p.z);
		this.setYRot((float) Math.toDegrees(OrbitMath.angle(slot, max, time)));

		if (client) {
			spawnClientParticles(p, OrbitMath.angle(slot, max, time));
		}
	}

	private void spawnClientParticles(Vec3 p, double angle) {
		// Vento tangencial: acompanha o sentido da órbita.
		if (this.tickCount % 2 == 0) {
			double tx = -Math.sin(angle) * 0.07;
			double tz = Math.cos(angle) * 0.07;
			int n = Fx.scaled(this.random, 1.0);
			for (int i = 0; i < n; i++) {
				this.level().addParticle(ParticleTypes.CLOUD, p.x, p.y, p.z, tx, 0.01, tz);
			}
		}
		// Faíscas de energia ocasionais.
		if (this.random.nextInt(4) == 0) {
			int n = Fx.scaled(this.random, 1.0);
			for (int i = 0; i < n; i++) {
				this.level().addParticle(ParticleTypes.END_ROD,
						p.x + (this.random.nextDouble() - 0.5) * 0.2,
						p.y + (this.random.nextDouble() - 0.5) * 0.2,
						p.z + (this.random.nextDouble() - 0.5) * 0.2,
						0.0, 0.01, 0.0);
			}
		}
	}

	@Override
	protected void readAdditionalSaveData(ValueInput input) {
		// noSave(): nunca é gravada no mundo.
	}

	@Override
	protected void addAdditionalSaveData(ValueOutput output) {
		// noSave(): nunca é gravada no mundo.
	}
}
