package com.valorantpack.entity;

import com.valorantpack.config.ModConfig;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** Posição determinística das facas em órbita (mesma fórmula no cliente e no servidor). */
public final class OrbitMath {
	private OrbitMath() {
	}

	/**
	 * @param time tempo de jogo em ticks (level.getGameTime()), igual para todas as facas
	 */
	public static Vec3 position(Entity owner, int slot, int max, double time) {
		ModConfig cfg = ModConfig.get();
		double angle = time * cfg.orbitSpinSpeed + slot * (Math.PI * 2.0 / Math.max(1, max));
		double y = owner.getY() + owner.getBbHeight() * 0.6 + Math.sin(time * 0.12 + slot * 1.3) * 0.1;
		return new Vec3(
				owner.getX() + Math.cos(angle) * cfg.orbitRadius,
				y,
				owner.getZ() + Math.sin(angle) * cfg.orbitRadius);
	}

	/** Ângulo atual do slot (usado para a direção do vento tangencial). */
	public static double angle(int slot, int max, double time) {
		return time * ModConfig.get().orbitSpinSpeed + slot * (Math.PI * 2.0 / Math.max(1, max));
	}
}
