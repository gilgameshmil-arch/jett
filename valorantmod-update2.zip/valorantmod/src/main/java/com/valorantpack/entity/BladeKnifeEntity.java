package com.valorantpack.entity;

import com.valorantpack.ability.AbilityManager;
import com.valorantpack.config.ModConfig;
import com.valorantpack.fx.Fx;
import com.valorantpack.registry.ModItems;
import com.valorantpack.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Faca de energia arremessada. Voa reta (sem gravidade), causa dano configurável,
 * detecta acerto na cabeça e avisa o {@link AbilityManager} ao terminar.
 *
 * A eliminação em si é detectada por AbilityManager via ServerLivingEntityEvents.AFTER_DEATH
 * (DamageSource.getDirectEntity() == esta faca), o que também cobre mortes causadas
 * por efeitos secundários de outros mods que reagem ao dano.
 */
public class BladeKnifeEntity extends ThrowableItemProjectile {
	private boolean resolved;

	public BladeKnifeEntity(EntityType<? extends BladeKnifeEntity> type, Level level) {
		super(type, level);
		this.setNoGravity(true);
	}

	@Override
	protected Item getDefaultItem() {
		return ModItems.BLADE_STORM_KNIFE;
	}

	@Override
	protected double getDefaultGravity() {
		return 0.0;
	}

	@Override
	public void tick() {
		super.tick();
		if (this.level().isClientSide()) {
			spawnTrail();
		} else if (this.tickCount > ModConfig.get().knifeMaxLifeTicks) {
			resolve();
		}
	}

	/** Rastro de vento e energia (apenas visual, no cliente, respeitando a densidade configurada). */
	private void spawnTrail() {
		Vec3 now = this.position();
		Vec3 prev = new Vec3(this.xo, this.yo, this.zo);
		for (int i = 0; i < 3; i++) {
			double t = i / 3.0;
			Vec3 p = prev.lerp(now, t);
			int n = Fx.scaled(this.random, 1.0);
			for (int k = 0; k < n; k++) {
				this.level().addParticle(ParticleTypes.END_ROD, p.x, p.y, p.z, 0.0, 0.0, 0.0);
			}
			if (i == 0) {
				int c = Fx.scaled(this.random, 0.7);
				for (int k = 0; k < c; k++) {
					this.level().addParticle(ParticleTypes.CLOUD, p.x, p.y, p.z,
							(this.random.nextDouble() - 0.5) * 0.02, (this.random.nextDouble() - 0.5) * 0.02,
							(this.random.nextDouble() - 0.5) * 0.02);
				}
			}
		}
	}

	@Override
	protected void onHitEntity(EntityHitResult hit) {
		if (!(this.level() instanceof ServerLevel server)) {
			return;
		}
		Entity target = hit.getEntity();
		Entity owner = this.getOwner();
		ModConfig cfg = ModConfig.get();

		if (target == owner || !(target instanceof LivingEntity living)) {
			return;
		}
		if (target instanceof Player && !cfg.damagePlayers) {
			resolve();
			return;
		}

		Vec3 where = hit.getLocation();
		boolean headshot = where.y >= target.getY() + target.getBbHeight() * 0.82;
		float damage = cfg.knifeDamage * (headshot ? cfg.headshotMultiplier : 1.0f);

		living.invulnerableTime = 0; // cada faca precisa poder causar dano mesmo em acertos consecutivos
		DamageSource source = server.damageSources().thrown(this, owner);
		living.hurtServer(server, source, damage);

		Fx.knifeHit(server, where, headshot);
		Fx.sound(server, where, ModSounds.HIT, 0.9f, 1.0f);
		if (headshot) {
			Fx.sound(server, where, ModSounds.HEADSHOT, 0.7f, 1.0f);
		}
		resolve();
	}

	@Override
	protected void onHitBlock(BlockHitResult hit) {
		if (!(this.level() instanceof ServerLevel server)) {
			return;
		}
		Vec3 where = hit.getLocation();
		Fx.knifeHit(server, where, false);
		Fx.sound(server, where, ModSounds.HIT, 0.6f, 1.3f);
		resolve();
	}

	/** Encerra a faca e informa o dono (para a contagem de facas em voo). */
	private void resolve() {
		if (!this.resolved) {
			this.resolved = true;
			if (this.getOwner() instanceof ServerPlayer sp) {
				AbilityManager.onKnifeResolved(sp);
			}
		}
		this.discard();
	}
}
