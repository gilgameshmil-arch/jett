package com.valorantpack.mobility;

import com.valorantpack.config.ModConfig;
import com.valorantpack.fx.DisplayFx;
import com.valorantpack.fx.DisplayFx.Xf;
import com.valorantpack.fx.Fx;
import com.valorantpack.fx.FxClock;
import com.valorantpack.fx.Quat;
import com.valorantpack.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/**
 * Cloudburst (E): lança uma orbe que voa até bater num bloco (ou no alcance máximo) e então
 * "estoura" numa ESFERA de fumaça 3D.
 *
 * A esfera são duas cascas de modelo (cloud_shell_outer / cloud_shell_inner), cada uma feita de discos
 * cruzados com textura de fumaça, girando em sentidos opostos e "respirando" (keyframes de escala).
 * No fim, as cascas encolhem em etapas (a externa primeiro) = a fumaça se dissipa gradualmente.
 * Partículas tangenciais em volta da superfície reforçam o movimento de fumaça rodando.
 * Tudo é entidade do servidor => visível para todos os jogadores.
 */
final class Cloudburst {
	private static final class Orb {
		final ServerLevel level;
		final UUID owner;
		final UUID display;
		Vec3 pos;
		Vec3 vel;
		int age;
		final int maxAge;

		Orb(ServerLevel level, UUID owner, UUID display, Vec3 pos, Vec3 vel, int maxAge) {
			this.level = level;
			this.owner = owner;
			this.display = display;
			this.pos = pos;
			this.vel = vel;
			this.maxAge = maxAge;
		}
	}

	private static final class Cloud {
		final ServerLevel level;
		final Vec3 center;
		final double radius;
		final int life;
		int age;

		Cloud(ServerLevel level, Vec3 center, double radius, int life) {
			this.level = level;
			this.center = center;
			this.radius = radius;
			this.life = life;
		}
	}

	private static final List<Orb> ORBS = new ArrayList<>();
	private static final List<Cloud> CLOUDS = new ArrayList<>();

	private Cloudburst() {
	}

	static void cast(ServerPlayer player, ServerLevel level) {
		ModConfig cfg = ModConfig.get();
		Vec3 look = player.getLookAngle();
		Vec3 start = player.getEyePosition().add(look.scale(0.7)).subtract(0, 0.25, 0);
		Vec3 vel = look.scale(cfg.cloudThrowSpeed);
		int maxAge = (int) Math.ceil(cfg.cloudMaxRange / cfg.cloudThrowSpeed);

		UUID display = DisplayFx.spawn(level, start, "cloud_orb", Xf.of(Quat.IDENTITY, 0.8), 1);
		ORBS.add(new Orb(level, player.getUUID(), display, start, vel, maxAge));
		Fx.sound(level, start, ModSounds.CLOUD_THROW, 1.0f, 1.0f);
		Fx.spray(level, ParticleTypes.CLOUD, start.x, start.y, start.z, 8, 0.15, 0.15, 0.15, 0.05);
	}

	static void tick(MinecraftServer server) {
		tickOrbs(server);
		tickClouds();
	}

	static void clear() {
		ORBS.clear();
		CLOUDS.clear();
	}

	// ------------------------------------------------------------------ orbe em voo

	private static void tickOrbs(MinecraftServer server) {
		Iterator<Orb> it = ORBS.iterator();
		while (it.hasNext()) {
			Orb o = it.next();
			ServerPlayer owner = server.getPlayerList().getPlayer(o.owner);
			if (owner == null) {
				DisplayFx.remove(o.level, o.display);
				it.remove();
				continue;
			}
			o.age++;
			o.vel = new Vec3(o.vel.x * 0.995, o.vel.y - 0.025, o.vel.z * 0.995);
			Vec3 next = o.pos.add(o.vel);
			BlockHitResult hit = o.level.clip(new ClipContext(o.pos, next, ClipContext.Block.COLLIDER,
					ClipContext.Fluid.NONE, owner));

			if (hit.getType() != HitResult.Type.MISS) {
				double R = ModConfig.get().cloudRadius;
				Vec3 c = hit.getLocation().add(
						hit.getDirection().getStepX() * R * 0.5,
						hit.getDirection().getStepY() * R * 0.5,
						hit.getDirection().getStepZ() * R * 0.5);
				DisplayFx.remove(o.level, o.display);
				burst(o.level, c);
				it.remove();
				continue;
			}
			o.pos = next;
			DisplayFx.teleport(o.level, o.display, o.pos);
			// rastro de vento atrás da orbe
			Fx.spray(o.level, ParticleTypes.CLOUD, o.pos.x, o.pos.y, o.pos.z, 2, 0.08, 0.08, 0.08, 0.01);
			if ((o.age & 1) == 0) {
				Fx.dir(o.level, ParticleTypes.END_ROD, o.pos.x, o.pos.y, o.pos.z,
						-o.vel.x * 0.1, -o.vel.y * 0.1, -o.vel.z * 0.1);
			}
			if (o.age >= o.maxAge) {
				DisplayFx.remove(o.level, o.display);
				burst(o.level, o.pos);
				it.remove();
			}
		}
	}

	// ------------------------------------------------------------------ esfera

	private static void burst(ServerLevel level, Vec3 center) {
		ModConfig cfg = ModConfig.get();
		double R = cfg.cloudRadius;
		int life = cfg.cloudDurationTicks;
		double outerS = 2.0 * R;          // o modelo tem 1 bloco de diâmetro => escala = diâmetro
		double innerS = 2.0 * R * 0.80;

		Fx.sound(level, center, ModSounds.CLOUD_BURST, 1.4f, 1.0f);
		// onda de estouro (partículas): casca esférica expandindo
		int n = Fx.scaled(level.random, 70);
		for (int i = 0; i < n; i++) {
			Vec3 d = randomUnit(level);
			Fx.dir(level, ParticleTypes.CLOUD, center.x, center.y, center.z, d.x * 0.45, d.y * 0.45, d.z * 0.45);
		}

		UUID outer = DisplayFx.spawn(level, center, "cloud_shell_outer", Xf.of(Quat.IDENTITY, 0.5), 1);
		UUID inner = DisplayFx.spawn(level, center, "cloud_shell_inner",
				Xf.of(Quat.axisAngleDeg(0, 1, 0, 45), 0.4), 1);
		CLOUDS.add(new Cloud(level, center, R, life));

		// --- crescimento (t=2 para o cliente já ter recebido a entidade pequena)
		FxClock.after(2, () -> {
			DisplayFx.animate(level, outer, Xf.of(spin(1, 40), outerS), 8);
			DisplayFx.animate(level, inner, Xf.of(spin(-1, 60), innerS), 8);
		});
		// --- giro contínuo em sentidos opostos + "respiração" de escala
		int steps = Math.max(0, (life - 50) / 8);
		for (int k = 1; k <= steps; k++) {
			final int kk = k;
			FxClock.after(10 + k * 8, () -> {
				double breathe = 1.0 + 0.045 * ((kk & 1) == 0 ? 1.0 : -1.0);
				DisplayFx.animate(level, outer, Xf.of(spin(1, 40 + 100.0 * kk), outerS * breathe), 8);
				DisplayFx.animate(level, inner, Xf.of(spin(-1, 60 + 130.0 * kk), innerS * (2.0 - breathe)), 8);
			});
		}
		// --- dissipação gradual: externa encolhe primeiro, depois some; interna por último
		double endAngle = 40 + 100.0 * (steps + 1);
		FxClock.after(Math.max(12, life - 40), () ->
				DisplayFx.animate(level, outer, Xf.of(spin(1, endAngle), outerS * 0.72), 20));
		FxClock.after(Math.max(14, life - 20), () -> {
			DisplayFx.animate(level, outer, Xf.of(spin(1, endAngle + 90), 0.02), 20);
			DisplayFx.animate(level, inner, Xf.of(spin(-1, 60 + 130.0 * (steps + 1)), innerS * 0.55), 12);
		});
		FxClock.after(Math.max(16, life - 8), () ->
				DisplayFx.animate(level, inner, Xf.of(spin(-1, 60 + 130.0 * (steps + 2)), 0.02), 8));
		FxClock.after(life + 2, () -> {
			DisplayFx.remove(level, outer);
			DisplayFx.remove(level, inner);
			Fx.spray(level, ParticleTypes.POOF, center.x, center.y, center.z, 24, R * 0.4, R * 0.4, R * 0.4, 0.02);
		});
	}

	/** Rotação em torno de um eixo levemente inclinado (gera movimento "rolando" em vez de um giro chapado). */
	private static Quat spin(int dir, double degrees) {
		return Quat.axisAngleDeg(0.15 * dir, 1.0, 0.1 * dir, dir * degrees);
	}

	private static void tickClouds() {
		Iterator<Cloud> it = CLOUDS.iterator();
		while (it.hasNext()) {
			Cloud c = it.next();
			c.age++;
			if (c.age > c.life - 6) {
				it.remove();
				continue;
			}
			if ((c.age & 1) == 0) {
				// fumaça "escorrendo" em volta da superfície (tangente em torno do eixo Y)
				int n = Fx.scaled(c.level.random, 5);
				for (int i = 0; i < n; i++) {
					Vec3 u = randomUnit(c.level);
					Vec3 p = c.center.add(u.scale(c.radius * (0.82 + 0.15 * c.level.random.nextDouble())));
					double tx = -u.z;
					double tz = u.x;
					double len = Math.max(1.0E-3, Math.sqrt(tx * tx + tz * tz));
					Fx.dir(c.level, ParticleTypes.CLOUD, p.x, p.y, p.z, tx / len * 0.14, 0.0, tz / len * 0.14);
				}
			}
		}
	}

	private static Vec3 randomUnit(ServerLevel level) {
		double z = level.random.nextDouble() * 2.0 - 1.0;
		double a = level.random.nextDouble() * Math.PI * 2.0;
		double r = Math.sqrt(1.0 - z * z);
		return new Vec3(r * Math.cos(a), z, r * Math.sin(a));
	}
}
