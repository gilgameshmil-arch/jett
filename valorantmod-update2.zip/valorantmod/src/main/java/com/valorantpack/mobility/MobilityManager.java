package com.valorantpack.mobility;

import com.valorantpack.config.ModConfig;
import com.valorantpack.network.MobilitySyncPayload;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Habilidades de mobilidade da Jett: Cloudburst (E), Tailwind (C), Updraft (Q).
 *
 * Servidor: valida recarga, dispara efeitos visíveis a todos e informa o cliente (MobilitySyncPayload).
 * Cliente: aplica o movimento (dash/impulso) imediatamente, para resposta sem atraso de rede.
 */
public final class MobilityManager {
	public static final int CLOUDBURST = 0;
	public static final int TAILWIND = 1;
	public static final int UPDRAFT = 2;

	public static final int EVENT_NONE = 0;
	public static final int EVENT_USED = 1;
	public static final int EVENT_DENIED = 2;

	/** Tick do servidor em que cada recarga termina. */
	private static final Map<UUID, int[]> COOLDOWN_UNTIL = new HashMap<>();

	private MobilityManager() {
	}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(MobilityManager::tick);
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
			Cloudburst.clear();
			Tailwind.clear();
			Updraft.clear();
			com.valorantpack.fx.FxClock.clear();
		});
	}

	private static void tick(MinecraftServer server) {
		Cloudburst.tick(server);
		Tailwind.tick(server);
		Updraft.tick(server);
	}

	/** Pedido do cliente. {@code dx/dz}: direção horizontal do dash (já relativa à câmera). */
	public static void handleAction(ServerPlayer player, int ability, float dx, float dz) {
		if (ability < CLOUDBURST || ability > UPDRAFT) {
			return;
		}
		if (!player.isAlive() || player.isSpectator() || !(player.level() instanceof ServerLevel level)) {
			return;
		}
		MinecraftServer server = level.getServer();
		int now = server.getTickCount();
		int[] until = COOLDOWN_UNTIL.computeIfAbsent(player.getUUID(), id -> new int[3]);

		if (now < until[ability]) {
			send(player, ability, until[ability] - now, EVENT_DENIED);
			return;
		}
		ModConfig cfg = ModConfig.get();
		int cd;
		switch (ability) {
			case CLOUDBURST -> {
				cd = cfg.cloudburstCooldownSeconds * 20;
				Cloudburst.cast(player, level);
			}
			case TAILWIND -> {
				cd = cfg.tailwindCooldownSeconds * 20;
				double x = Float.isFinite(dx) ? dx : 0.0;
				double z = Float.isFinite(dz) ? dz : 0.0;
				Tailwind.cast(player, level, x, z);
			}
			default -> {
				cd = cfg.updraftCooldownSeconds * 20;
				Updraft.cast(player, level);
			}
		}
		until[ability] = now + cd;
		send(player, ability, cd, EVENT_USED);
	}

	private static void send(ServerPlayer player, int ability, int cooldownTicks, int event) {
		ServerPlayNetworking.send(player, new MobilitySyncPayload(ability, cooldownTicks, event));
	}
}
