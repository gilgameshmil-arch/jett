package com.valorantpack.mobility;

import com.valorantpack.config.ModConfig;
import com.valorantpack.fx.DisplayFx;
import com.valorantpack.fx.DisplayFx.Xf;
import com.valorantpack.fx.Fx;
import com.valorantpack.fx.FxClock;
import com.valorantpack.fx.Quat;
import com.valorantpack.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/**
 * Updraft (Q): impulso vertical.
 *
 * O impulso é aplicado pelo cliente (ClientMobility). Aqui: coluna de vento 3D em hélice (modelo wind_spiral)
 * girando e subindo junto com o jogador, ondas de choque no chão, anéis de ar deixados no caminho que
 * encolhem e sobem (corrente ascendente) e partículas em espiral. Também zera a distância de queda
 * (sem dano de queda após o Updraft, até pousar ou o limite da configuração).
 */
final class Updraft {
	private static final int VISUAL_TICKS = 26;
	private static final double SPIRAL_W = 2.4;
	private static final double SPIRAL_H = 3.6;

	private static final class Session {
		final ServerLevel level;
		final UUID player;
		final UUID spiral;
		int age;
		boolean visualDone;
		boolean protectDone;

		Session(ServerLevel level, UUID player, UUID spiral) {
			this.level = level;
			this.player = player;
			this.spiral = spiral;
		}
	}

	private static final List<Session> SESSIONS = new ArrayList<>();

	private Updraft() {
	}

	static void cast(ServerPlayer player, ServerLevel level) {
		Vec3 feet = player.position();
		Vec3 body = feet.add(0, 1.0, 0);

		UUID spiral = DisplayFx.spawn(level, body, "wind_spiral", Xf.of(Quat.IDENTITY, SPIRAL_W * 0.5, SPIRAL_H * 0.5, SPIRAL_W * 0.5), 2);
		SESSIONS.add(new Session(level, player.getUUID(), spiral));
		FxClock.after(1, () -> DisplayFx.animate(level, spiral, Xf.of(Quat.IDENTITY, SPIRAL_W, SPIRAL_H, SPIRAL_W), 3));

		Fx.sound(level, feet, ModSounds.UPDRAFT, 1.0f, 1.0f);

		// ondas de choque no chão (dois anéis escalonados)
		for (int i = 0; i < 2; i++) {
			final int delay = i * 3;
			FxClock.after(1 + delay, () -> {
				UUID ring = DisplayFx.spawn(level, feet.add(0, 0.15, 0), "wind_ring", Xf.of(Quat.IDENTITY, 1.2), 1);
				FxClock.after(2, () -> DisplayFx.animate(level, ring, Xf.of(Quat.axisAngleDeg(0, 1, 0, 110), 6.0 + delay * 0.4), 7));
				FxClock.after(10, () -> DisplayFx.remove(level, ring));
			});
		}
		// explosão radial de poeira de vento no chão
		for (int i = 0; i < 24; i++) {
			double a = i * (Math.PI * 2.0 / 24.0);
			Fx.dir(level, ParticleTypes.CLOUD, feet.x + Math.cos(a) * 0.4, feet.y + 0.1, feet.z + Math.sin(a) * 0.4,
					Math.cos(a) * 0.3, 0.03, Math.sin(a) * 0.3);
		}
	}

	static void clear() {
		SESSIONS.clear();
	}

	static void tick(MinecraftServer server) {
		int protect = ModConfig.get().updraftFallProtectionTicks;
		Iterator<Session> it = SESSIONS.iterator();
		while (it.hasNext()) {
			Session s = it.next();
			ServerPlayer p = server.getPlayerList().getPlayer(s.player);
			if (p == null || !p.isAlive() || p.level() != s.level) {
				DisplayFx.remove(s.level, s.spiral);
				it.remove();
				continue;
			}
			s.age++;

			if (!s.visualDone) {
				visual(s, p);
			}
			if (!s.protectDone) {
				if (s.age > protect || (s.age > 8 && p.onGround())) {
					s.protectDone = true;
				} else {
					p.resetFallDistance();
				}
			}
			if (s.visualDone && s.protectDone) {
				it.remove();
			}
		}
	}

	private static void visual(Session s, ServerPlayer p) {
		ServerLevel level = s.level;
		Vec3 feet = p.position();
		Vec3 body = feet.add(0, 1.0, 0);

		if (s.age <= VISUAL_TICKS) {
			DisplayFx.teleport(level, s.spiral, body);
			if (s.age % 3 == 0) { // keyframes curtos de giro (< 180 graus) => hélice girando rápido
				Quat q = Quat.axisAngleDeg(0, 1, 0, s.age * 40.0);
				DisplayFx.animate(level, s.spiral, Xf.of(q, SPIRAL_W, SPIRAL_H, SPIRAL_W), 3);
			}
			// anéis de ar deixados no caminho: ficam, encolhem e sobem (corrente ascendente)
			if (s.age % 2 == 0 && s.age <= 20) {
				final double base = s.age * 25.0;
				UUID ring = DisplayFx.spawn(level, feet.add(0, 0.2, 0), "wind_ring",
						Xf.of(Quat.axisAngleDeg(0, 1, 0, base), 2.4), 1);
				FxClock.after(2, () -> DisplayFx.animate(level, ring,
						Xf.of(Quat.axisAngleDeg(0, 1, 0, base + 120.0), 0.7).withTranslation(0, 1.6, 0), 9));
				FxClock.after(12, () -> DisplayFx.remove(level, ring));
			}
			// hélice dupla de partículas subindo em volta do jogador
			for (int strand = 0; strand < 2; strand++) {
				double a = s.age * 0.85 + strand * Math.PI;
				double r = 0.85 + 0.25 * Math.sin(s.age * 0.4 + strand);
				double yy = ((s.age * 0.32 + strand * 1.4) % 3.2) - 0.4;
				Fx.dir(level, strand == 0 ? ParticleTypes.END_ROD : ParticleTypes.CLOUD,
						feet.x + Math.cos(a) * r, feet.y + yy, feet.z + Math.sin(a) * r,
						-Math.sin(a) * 0.05, 0.14, Math.cos(a) * 0.05);
			}
			Fx.spray(level, ParticleTypes.ELECTRIC_SPARK, feet.x, feet.y + 1.0, feet.z, 1, 0.5, 0.8, 0.5, 0.04);
		}
		if (s.age == VISUAL_TICKS - 3) {
			DisplayFx.animate(level, s.spiral,
					Xf.of(Quat.axisAngleDeg(0, 1, 0, s.age * 40.0), SPIRAL_W * 1.2, SPIRAL_H * 1.3, SPIRAL_W * 1.2), 4);
		}
		if (s.age == VISUAL_TICKS) {
			DisplayFx.animate(level, s.spiral, Xf.of(Quat.IDENTITY, 0.02, 0.02, 0.02), 4);
		}
		if (s.age >= VISUAL_TICKS + 5) {
			DisplayFx.remove(level, s.spiral);
			s.visualDone = true;
		}
	}
}
