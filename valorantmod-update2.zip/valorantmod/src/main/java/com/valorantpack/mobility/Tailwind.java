package com.valorantpack.mobility;

import com.valorantpack.config.ModConfig;
import com.valorantpack.fx.DisplayFx;
import com.valorantpack.fx.DisplayFx.Xf;
import com.valorantpack.fx.Fx;
import com.valorantpack.fx.FxClock;
import com.valorantpack.fx.Quat;
import com.valorantpack.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/**
 * Tailwind (C): dash horizontal.
 *
 * O MOVIMENTO é aplicado pelo cliente (ver client/ClientMobility): é o que o deixa imediato e fluido,
 * igual ao movimento vanilla (o servidor confia na posição enviada pelo cliente).
 * Este lado cuida do que TODOS veem: túnel de vento 3D acompanhando o jogador (aneis + correntes girando
 * em torno do eixo do dash), onda de choque na partida, anéis de vento deixados no caminho que se
 * expandem e somem, e partículas em espiral. O efeito dura o dash inteiro + um breve rastro final.
 */
final class Tailwind {
	private static final class Session {
		final ServerLevel level;
		final UUID player;
		final Vec3 dir;
		final Quat align;
		final UUID tunnel;
		final int dashTicks;
		int age;

		Session(ServerLevel level, UUID player, Vec3 dir, Quat align, UUID tunnel, int dashTicks) {
			this.level = level;
			this.player = player;
			this.dir = dir;
			this.align = align;
			this.tunnel = tunnel;
			this.dashTicks = dashTicks;
		}
	}

	private static final List<Session> SESSIONS = new ArrayList<>();
	private static final double TUNNEL_W = 2.6;
	private static final double TUNNEL_L = 4.4;

	private Tailwind() {
	}

	static void cast(ServerPlayer player, ServerLevel level, double dx, double dz) {
		Vec3 dir = new Vec3(dx, 0, dz);
		if (dir.lengthSqr() < 1.0E-6) {
			Vec3 look = player.getLookAngle();
			dir = new Vec3(look.x, 0, look.z);
		}
		dir = dir.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, 1) : dir.normalize();

		Quat align = Quat.fromTo(Quat.UP, dir);
		ModConfig cfg = ModConfig.get();
		Vec3 c = center(player, dir);

		UUID tunnel = DisplayFx.spawn(level, c, "wind_tunnel",
				Xf.of(align, TUNNEL_W * 0.4, TUNNEL_L * 0.4, TUNNEL_W * 0.4), 2);
		SESSIONS.add(new Session(level, player.getUUID(), dir, align, tunnel, cfg.dashTicks));

		// o túnel "abre" rapidamente
		FxClock.after(1, () -> DisplayFx.animate(level, tunnel, Xf.of(align, TUNNEL_W, TUNNEL_L, TUNNEL_W), 3));

		// onda de choque na partida: anel perpendicular ao dash que se expande
		Vec3 start = player.position().add(0, player.getBbHeight() * 0.5, 0);
		UUID shock = DisplayFx.spawn(level, start, "wind_ring", Xf.of(align, 1.0), 1);
		FxClock.after(1, () -> DisplayFx.animate(level, shock,
				Xf.of(align.mul(Quat.axisAngleDeg(0, 1, 0, 120)), 5.5), 6));
		FxClock.after(8, () -> DisplayFx.remove(level, shock));

		Fx.sound(level, start, ModSounds.TAILWIND, 1.0f, 1.0f);
		// explosão de partículas para trás
		for (int i = 0; i < 18; i++) {
			double a = i * (Math.PI * 2.0 / 18.0);
			Vec3 u = perpU(dir);
			Vec3 v = dir.cross(u);
			Vec3 off = u.scale(Math.cos(a)).add(v.scale(Math.sin(a)));
			Fx.dir(level, ParticleTypes.CLOUD, start.x + off.x * 0.5, start.y + off.y * 0.5, start.z + off.z * 0.5,
					off.x * 0.18 - dir.x * 0.25, off.y * 0.18 - dir.y * 0.25, off.z * 0.18 - dir.z * 0.25);
		}
	}

	static void clear() {
		SESSIONS.clear();
	}

	static void tick(MinecraftServer server) {
		Iterator<Session> it = SESSIONS.iterator();
		while (it.hasNext()) {
			Session s = it.next();
			ServerPlayer p = server.getPlayerList().getPlayer(s.player);
			if (p == null || !p.isAlive() || p.level() != s.level) {
				DisplayFx.remove(s.level, s.tunnel);
				it.remove();
				continue;
			}
			s.age++;
			int fadeStart = s.dashTicks + 2;

			if (s.age <= fadeStart) {
				DisplayFx.teleport(s.level, s.tunnel, center(p, s.dir));
				// gira o túnel em torno do próprio eixo (keyframes curtos < 180 graus)
				if ((s.age & 1) == 0) {
					Quat q = s.align.mul(Quat.axisAngleDeg(0, 1, 0, s.age * 70.0));
					DisplayFx.animate(s.level, s.tunnel, Xf.of(q, TUNNEL_W, TUNNEL_L, TUNNEL_W), 2);
				}
			}
			if (s.age <= s.dashTicks) {
				trailRing(s, p);
				spiral(s, p);
			}
			if (s.age == fadeStart + 1) {
				DisplayFx.animate(s.level, s.tunnel,
						Xf.of(s.align.mul(Quat.axisAngleDeg(0, 1, 0, s.age * 70.0)), TUNNEL_W * 1.3, TUNNEL_L * 1.5, TUNNEL_W * 1.3), 4);
			}
			if (s.age == fadeStart + 3) {
				DisplayFx.animate(s.level, s.tunnel, Xf.of(s.align, 0.02, 0.02, 0.02), 4);
			}
			if (s.age >= fadeStart + 8) {
				DisplayFx.remove(s.level, s.tunnel);
				it.remove();
			}
		}
	}

	/** Anel que fica no ponto do caminho, expande girando e some em ~9 ticks. */
	private static void trailRing(Session s, ServerPlayer p) {
		Vec3 pos = p.position().add(0, p.getBbHeight() * 0.5, 0).subtract(s.dir.scale(0.4));
		Quat start = s.align.mul(Quat.axisAngleDeg(0, 1, 0, s.age * 35.0));
		UUID ring = DisplayFx.spawn(s.level, pos, "wind_ring", Xf.of(start, 1.5), 1);
		ServerLevel level = s.level;
		Quat end = s.align.mul(Quat.axisAngleDeg(0, 1, 0, s.age * 35.0 + 100.0));
		FxClock.after(2, () -> DisplayFx.animate(level, ring, Xf.of(end, 3.2), 7));
		FxClock.after(10, () -> DisplayFx.remove(level, ring));
	}

	/** Três filetes de partículas em hélice em volta do caminho, mais faíscas de vento. */
	private static void spiral(Session s, ServerPlayer p) {
		Vec3 c = p.position().add(0, p.getBbHeight() * 0.5, 0);
		Vec3 u = perpU(s.dir);
		Vec3 v = s.dir.cross(u);
		for (int k = 0; k < 3; k++) {
			double a = s.age * 1.15 + k * (Math.PI * 2.0 / 3.0);
			double r = 0.95;
			Vec3 off = u.scale(Math.cos(a) * r).add(v.scale(Math.sin(a) * r));
			Vec3 tang = u.scale(-Math.sin(a)).add(v.scale(Math.cos(a)));
			Vec3 vel = s.dir.scale(-0.22).add(tang.scale(0.06));
			Fx.dir(s.level, k == 0 ? ParticleTypes.END_ROD : ParticleTypes.CLOUD,
					c.x + off.x, c.y + off.y, c.z + off.z, vel.x, vel.y, vel.z);
		}
		Fx.spray(s.level, ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 2, 0.4, 0.4, 0.4, 0.05);
	}

	private static Vec3 center(ServerPlayer p, Vec3 dir) {
		return p.position().add(0, p.getBbHeight() * 0.5, 0).subtract(dir.scale(1.1));
	}

	private static Vec3 perpU(Vec3 dir) {
		Vec3 u = dir.cross(new Vec3(0, 1, 0));
		if (u.lengthSqr() < 1.0E-6) {
			u = new Vec3(1, 0, 0);
		}
		return u.normalize();
	}
}
