package com.valorantpack;

import com.valorantpack.ability.AbilityManager;
import com.valorantpack.config.ModConfig;
import com.valorantpack.network.ModNetworking;
import com.valorantpack.registry.ModEntities;
import com.valorantpack.registry.ModItems;
import com.valorantpack.registry.ModSounds;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Ponto de entrada comum (cliente + servidor).
 *
 * Ordem de inicialização: config -> sons -> itens -> entidades -> rede -> gerenciador de habilidades.
 * Para adicionar conteúdo futuro (armas, facas), crie a classe de registro correspondente e
 * chame o seu {@code init()} aqui.
 */
public class ValorantMod implements ModInitializer {
	public static final String MOD_ID = "valorantmod";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModConfig.load();
		ModSounds.init();
		ModItems.init();
		ModEntities.init();
		ModNetworking.registerCommon();
		AbilityManager.init();
		com.valorantpack.fx.DisplayFx.init();
		com.valorantpack.fx.FxClock.init();
		com.valorantpack.mobility.MobilityManager.init();
		LOGGER.info("Valorant Ultimate Weapon Pack (etapa 1: Blade Storm) carregado.");
	}
}
