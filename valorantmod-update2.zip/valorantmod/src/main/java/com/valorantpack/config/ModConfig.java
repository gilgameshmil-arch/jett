package com.valorantpack.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.valorantpack.ValorantMod;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Configuração em JSON (config/valorantmod.json). Lida no servidor (e no cliente em jogo local).
 * Em multiplayer quem manda é a configuração do servidor; o HUD recebe o que precisa por pacote.
 *
 * Todos os valores são validados em {@link #sanitize()}. Reinicie o jogo/servidor para aplicar mudanças.
 */
public final class ModConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static ModConfig instance = new ModConfig();

	// ------------------------------------------------------------ Blade Storm
	/** Quantidade de facas da Ultimate (1 a 10). */
	public int knifeCount = 5;
	/** Dano base de cada faca (em pontos de vida; 2 = 1 coração). */
	public float knifeDamage = 8.0f;
	/** Multiplicador de dano em acerto na cabeça. */
	public float headshotMultiplier = 2.5f;
	/** Velocidade da faca em blocos por tick. */
	public double knifeSpeed = 3.0;
	/** Tempo de vida máximo da faca em voo (ticks). */
	public int knifeMaxLifeTicks = 50;
	/** Intervalo mínimo entre lançamentos (ticks). */
	public int throwIntervalTicks = 6;
	/** Intervalo entre facas ao lançar todas de uma vez (ticks). */
	public int volleyIntervalTicks = 2;
	/** Imprecisão (graus) ao lançar todas as facas restantes. */
	public double volleySpreadDegrees = 6.0;
	/** Recarga da Ultimate depois que ela termina (segundos). */
	public int ultimateCooldownSeconds = 30;
	/** Janela (ticks) após lançar a última faca em que uma eliminação ainda recupera as facas. */
	public int recoveryGraceTicks = 60;
	/** Se verdadeiro, eliminar um alvo com a faca recupera todas as facas. */
	public boolean recoverOnKill = true;
	/** Se falso, as facas não acertam jogadores. */
	public boolean damagePlayers = true;
	/** Se verdadeiro, a tecla de ativação exige o item no inventário. */
	public boolean keyRequiresItem = true;
	/** Duração máxima da Ultimate em segundos (0 = sem limite). */
	public int maxActiveSeconds = 0;

	// ------------------------------------------------------------ Mobilidade (Cloudburst / Tailwind / Updraft)
	/** Recarga do Cloudburst (segundos). */
	public int cloudburstCooldownSeconds = 25;
	/** Raio da esfera de fumaça (blocos). */
	public double cloudRadius = 4.0;
	/** Duração da esfera de fumaça (ticks; 20 = 1 s). */
	public int cloudDurationTicks = 110;
	/** Velocidade da orbe lançada (blocos por tick). */
	public double cloudThrowSpeed = 1.4;
	/** Alcance máximo da orbe (blocos) antes de estourar no ar. */
	public double cloudMaxRange = 32.0;
	/** Recarga do Tailwind (segundos). */
	public int tailwindCooldownSeconds = 8;
	/** Velocidade do dash em blocos por tick (1.9 = 38 blocos/s). Usada pelo CLIENTE (movimento é do cliente). */
	public double dashSpeed = 1.9;
	/** Duração do dash em ticks. */
	public int dashTicks = 7;
	/** Recarga do Updraft (segundos). */
	public int updraftCooldownSeconds = 10;
	/** Impulso vertical do Updraft (blocos por tick; ~1.05 = 6 blocos). Usado pelo CLIENTE. */
	public double updraftVelocity = 1.05;
	/** Ticks (máx.) de proteção contra dano de queda após o Updraft. */
	public int updraftFallProtectionTicks = 160;
	/** Efeitos 3D (item_display). Desligue para servidores que preferem só partículas. */
	public boolean displayFx = true;
	/** Multiplicador da distância de visão dos efeitos 3D (1.0 = ~64 blocos). */
	public double fxViewRange = 3.0;

	// ------------------------------------------------------------ Visual / desempenho
	/** Raio da órbita das facas em blocos. */
	public double orbitRadius = 1.05;
	/** Velocidade de rotação da órbita (radianos por tick). */
	public double orbitSpinSpeed = 0.16;
	/** Multiplicador de partículas: 0 desliga, 1 normal, 0.5 reduz pela metade (PCs fracos). */
	public double particleDensity = 1.0;

	private ModConfig() {
	}

	public static ModConfig get() {
		return instance;
	}

	public static void load() {
		Path path = FabricLoader.getInstance().getConfigDir().resolve(ValorantMod.MOD_ID + ".json");
		ModConfig loaded = null;
		if (Files.exists(path)) {
			try {
				String json = Files.readString(path, StandardCharsets.UTF_8);
				loaded = GSON.fromJson(json, ModConfig.class);
			} catch (IOException | RuntimeException e) {
				ValorantMod.LOGGER.error("Falha ao ler {}; usando valores padrão.", path, e);
			}
		}
		instance = loaded != null ? loaded : new ModConfig();
		instance.sanitize();
		save(path);
	}

	private static void save(Path path) {
		try {
			Files.createDirectories(path.getParent());
			Files.writeString(path, GSON.toJson(instance), StandardCharsets.UTF_8);
		} catch (IOException e) {
			ValorantMod.LOGGER.error("Falha ao gravar {}.", path, e);
		}
	}

	private void sanitize() {
		knifeCount = clamp(knifeCount, 1, 10);
		knifeDamage = Math.max(0.0f, knifeDamage);
		headshotMultiplier = Math.max(1.0f, headshotMultiplier);
		knifeSpeed = Math.max(0.2, Math.min(6.0, knifeSpeed));
		knifeMaxLifeTicks = clamp(knifeMaxLifeTicks, 5, 400);
		throwIntervalTicks = clamp(throwIntervalTicks, 1, 100);
		volleyIntervalTicks = clamp(volleyIntervalTicks, 1, 40);
		volleySpreadDegrees = Math.max(0.0, Math.min(45.0, volleySpreadDegrees));
		ultimateCooldownSeconds = clamp(ultimateCooldownSeconds, 0, 3600);
		recoveryGraceTicks = clamp(recoveryGraceTicks, 1, 600);
		maxActiveSeconds = clamp(maxActiveSeconds, 0, 3600);
		orbitRadius = Math.max(0.4, Math.min(3.0, orbitRadius));
		orbitSpinSpeed = Math.max(0.01, Math.min(1.0, orbitSpinSpeed));
		particleDensity = Math.max(0.0, Math.min(3.0, particleDensity));
		cloudburstCooldownSeconds = clamp(cloudburstCooldownSeconds, 0, 3600);
		cloudRadius = Math.max(1.0, Math.min(12.0, cloudRadius));
		cloudDurationTicks = clamp(cloudDurationTicks, 40, 1200);
		cloudThrowSpeed = Math.max(0.3, Math.min(4.0, cloudThrowSpeed));
		cloudMaxRange = Math.max(4.0, Math.min(128.0, cloudMaxRange));
		tailwindCooldownSeconds = clamp(tailwindCooldownSeconds, 0, 3600);
		dashSpeed = Math.max(0.3, Math.min(3.5, dashSpeed));
		dashTicks = clamp(dashTicks, 2, 30);
		updraftCooldownSeconds = clamp(updraftCooldownSeconds, 0, 3600);
		updraftVelocity = Math.max(0.2, Math.min(2.5, updraftVelocity));
		updraftFallProtectionTicks = clamp(updraftFallProtectionTicks, 0, 1200);
		fxViewRange = Math.max(0.5, Math.min(8.0, fxViewRange));
	}

	private static int clamp(int v, int lo, int hi) {
		return Math.max(lo, Math.min(hi, v));
	}
}
