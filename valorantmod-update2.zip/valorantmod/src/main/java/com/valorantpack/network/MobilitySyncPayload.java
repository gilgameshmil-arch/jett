package com.valorantpack.network;

import com.valorantpack.ValorantMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * Servidor -> cliente: recarga de uma habilidade de mobilidade.
 *
 * @param ability       índice da habilidade
 * @param cooldownTicks recarga restante em ticks
 * @param event         MobilityManager.EVENT_USED (aceita) ou EVENT_DENIED (recusada: cliente cancela o dash)
 */
public record MobilitySyncPayload(int ability, int cooldownTicks, int event) implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<MobilitySyncPayload> TYPE =
			new CustomPacketPayload.Type<>(ValorantMod.id("mobility_sync"));

	public static final StreamCodec<RegistryFriendlyByteBuf, MobilitySyncPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.VAR_INT, MobilitySyncPayload::ability,
			ByteBufCodecs.VAR_INT, MobilitySyncPayload::cooldownTicks,
			ByteBufCodecs.VAR_INT, MobilitySyncPayload::event,
			MobilitySyncPayload::new);

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
