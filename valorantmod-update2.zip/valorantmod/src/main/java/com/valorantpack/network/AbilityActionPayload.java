package com.valorantpack.network;

import com.valorantpack.ValorantMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * Cliente -> servidor: pedido de ação por tecla.
 * O servidor valida tudo (item, recarga, intervalo); o cliente só "pede".
 *
 * @param action ACTIVATE, THROW_ONE ou THROW_VOLLEY
 */
public record AbilityActionPayload(int action) implements CustomPacketPayload {
	public static final int ACTIVATE = 0;
	public static final int THROW_ONE = 1;
	public static final int THROW_VOLLEY = 2;

	public static final CustomPacketPayload.Type<AbilityActionPayload> TYPE =
			new CustomPacketPayload.Type<>(ValorantMod.id("ability_action"));

	public static final StreamCodec<RegistryFriendlyByteBuf, AbilityActionPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.VAR_INT, AbilityActionPayload::action,
			AbilityActionPayload::new);

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
