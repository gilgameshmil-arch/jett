package com.valorantpack.network;

import com.valorantpack.ValorantMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * Servidor -> cliente: estado da Ultimate para o HUD.
 *
 * @param active        Ultimate ativa
 * @param remaining     facas disponíveis
 * @param max           total de facas
 * @param cooldownTicks recarga restante (0 = pronta)
 * @param event         um dos AbilityManager.EVENT_* (dispara animações do HUD)
 */
public record AbilitySyncPayload(boolean active, int remaining, int max, int cooldownTicks, int event)
		implements CustomPacketPayload {

	public static final CustomPacketPayload.Type<AbilitySyncPayload> TYPE =
			new CustomPacketPayload.Type<>(ValorantMod.id("ability_sync"));

	public static final StreamCodec<RegistryFriendlyByteBuf, AbilitySyncPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.BOOL, AbilitySyncPayload::active,
			ByteBufCodecs.VAR_INT, AbilitySyncPayload::remaining,
			ByteBufCodecs.VAR_INT, AbilitySyncPayload::max,
			ByteBufCodecs.VAR_INT, AbilitySyncPayload::cooldownTicks,
			ByteBufCodecs.VAR_INT, AbilitySyncPayload::event,
			AbilitySyncPayload::new);

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
