package com.valorantpack.network;

import com.valorantpack.ability.AbilityManager;
import com.valorantpack.mobility.MobilityManager;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

/**
 * Registro dos pacotes. Deve rodar no entrypoint principal (cliente E servidor),
 * porque o tipo de pacote precisa existir dos dois lados antes de qualquer conexão.
 *
 * Os receptores do lado do cliente ficam em client/ValorantModClient.
 */
public final class ModNetworking {
	private ModNetworking() {
	}

	public static void registerCommon() {
		PayloadTypeRegistry.playS2C().register(AbilitySyncPayload.TYPE, AbilitySyncPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(AbilityActionPayload.TYPE, AbilityActionPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(MobilitySyncPayload.TYPE, MobilitySyncPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(MobilityActionPayload.TYPE, MobilityActionPayload.CODEC);

		// Os handlers já rodam na thread principal do servidor.
		ServerPlayNetworking.registerGlobalReceiver(AbilityActionPayload.TYPE,
				(payload, context) -> AbilityManager.handleAction(context.player(), payload.action()));
		ServerPlayNetworking.registerGlobalReceiver(MobilityActionPayload.TYPE,
				(payload, context) -> MobilityManager.handleAction(context.player(), payload.ability(), payload.dx(), payload.dz()));
	}
}
