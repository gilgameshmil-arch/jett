package com.valorantpack.network;

import com.valorantpack.ValorantMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * Cliente -> servidor: uso de uma habilidade de mobilidade.
 *
 * @param ability MobilityManager.CLOUDBURST / TAILWIND / UPDRAFT
 * @param dx      componente X da direção do dash (só Tailwind)
 * @param dz      componente Z da direção do dash (só Tailwind)
 */
public record MobilityActionPayload(int ability, float dx, float dz) implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<MobilityActionPayload> TYPE =
			new CustomPacketPayload.Type<>(ValorantMod.id("mobility_action"));

	public static final StreamCodec<RegistryFriendlyByteBuf, MobilityActionPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.VAR_INT, MobilityActionPayload::ability,
			ByteBufCodecs.FLOAT, MobilityActionPayload::dx,
			ByteBufCodecs.FLOAT, MobilityActionPayload::dz,
			MobilityActionPayload::new);

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
