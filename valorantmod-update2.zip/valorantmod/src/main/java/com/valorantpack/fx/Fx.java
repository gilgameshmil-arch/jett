package com.valorantpack.fx;

import com.valorantpack.config.ModConfig;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Central de efeitos (sons + partículas) do lado do servidor.
 *
 * Todo efeito do mod passa por aqui. Quando as armas e facas da etapa 2 chegarem,
 * os efeitos delas entram nesta classe (ou em classes irmãs deste pacote), e
 * partículas personalizadas (com textura própria) substituem as vanilla trocando
 * apenas os ParticleTypes usados abaixo.
 */
public final class Fx {
	private Fx() {
	}

	// ------------------------------------------------------------------ utilidades

	public static void sound(Level level, Vec3 pos, SoundEvent sound, float volume, float pitch) {
		level.playSound(null, pos.x, pos.y, pos.z, sound, SoundSource.PLAYERS, volume, pitch);
	}

	/** Converte uma quantidade-base em inteiro respeitando {@code particleDensity} (com sorteio da fração). */
	public static int scaled(RandomSource random, double base) {
		double v = base * ModConfig.get().particleDensity;
		int n = (int) Math.floor(v);
		if (random.nextDouble() < v - n) {
			n++;
		}
		return n;
	}

	/** Partículas espalhadas numa caixa (count > 0 escalado pela densidade). */
	public static void spray(ServerLevel level, ParticleOptions type, double x, double y, double z,
							  int count, double sx, double sy, double sz, double speed) {
		int n = scaled(level.random, count);
		if (n > 0) {
			level.sendParticles(type, x, y, z, n, sx, sy, sz, speed);
		}
	}

	/** Uma partícula com velocidade explícita (count = 0 faz o servidor tratar dx/dy/dz como velocidade). */
	public static void dir(ServerLevel level, ParticleOptions type, double x, double y, double z,
							double vx, double vy, double vz) {
		int n = scaled(level.random, 1.0);
		for (int i = 0; i < n; i++) {
			level.sendParticles(type, x, y, z, 0, vx, vy, vz, 1.0);
		}
	}

	// ------------------------------------------------------------------ efeitos da Blade Storm

	/** Explosão de ativação: anéis de vento no chão, espiral ascendente de energia e faíscas. */
	public static void activation(ServerLevel level, Entity player) {
		Vec3 f = player.position();
		for (int ring = 0; ring < 3; ring++) {
			double r = 0.4 + ring * 0.5;
			int n = 18 + ring * 6;
			double speed = 0.25 + ring * 0.12;
			for (int i = 0; i < n; i++) {
				double a = i * (Math.PI * 2.0 / n);
				double dx = Math.cos(a);
				double dz = Math.sin(a);
				dir(level, ParticleTypes.CLOUD, f.x + dx * r, f.y + 0.08, f.z + dz * r, dx * speed, 0.02, dz * speed);
			}
		}
		for (int i = 0; i < 24; i++) {
			double a = i * 0.55;
			dir(level, ParticleTypes.END_ROD, f.x + Math.cos(a) * 0.9, f.y + i * 0.085, f.z + Math.sin(a) * 0.9,
					-Math.sin(a) * 0.06, 0.04, Math.cos(a) * 0.06);
		}
		spray(level, ParticleTypes.ELECTRIC_SPARK, f.x, f.y + 1.0, f.z, 18, 0.5, 0.6, 0.5, 0.2);
	}

	/** Materialização de uma faca em órbita. */
	public static void knifeAppear(ServerLevel level, Vec3 pos) {
		spray(level, ParticleTypes.END_ROD, pos.x, pos.y, pos.z, 6, 0.12, 0.12, 0.12, 0.04);
		spray(level, ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y, pos.z, 4, 0.15, 0.15, 0.15, 0.1);
	}

	/** Rajada de vento no ponto de lançamento, empurrada para trás da trajetória. */
	public static void knifeThrow(ServerLevel level, Vec3 pos, Vec3 direction) {
		Vec3 back = direction.normalize().scale(-0.18);
		for (int i = 0; i < 4; i++) {
			dir(level, ParticleTypes.CLOUD, pos.x, pos.y, pos.z,
					back.x + (level.random.nextDouble() - 0.5) * 0.08,
					back.y + (level.random.nextDouble() - 0.5) * 0.08,
					back.z + (level.random.nextDouble() - 0.5) * 0.08);
		}
		spray(level, ParticleTypes.END_ROD, pos.x, pos.y, pos.z, 4, 0.05, 0.05, 0.05, 0.06);
	}

	/** Impacto da faca. Acerto na cabeça tem fogos brancos extras. */
	public static void knifeHit(ServerLevel level, Vec3 pos, boolean headshot) {
		spray(level, ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y, pos.z, headshot ? 24 : 12, 0.15, 0.15, 0.15, 0.25);
		spray(level, ParticleTypes.CRIT, pos.x, pos.y, pos.z, 8, 0.2, 0.2, 0.2, 0.3);
		if (headshot) {
			spray(level, ParticleTypes.FIREWORK, pos.x, pos.y, pos.z, 8, 0.1, 0.1, 0.1, 0.18);
		}
	}

	/** Recuperação por eliminação: onda de energia a partir do jogador. */
	public static void refresh(ServerLevel level, Entity player) {
		Vec3 c = player.position().add(0, player.getBbHeight() * 0.55, 0);
		for (int i = 0; i < 32; i++) {
			double a = i * (Math.PI * 2.0 / 32.0);
			dir(level, ParticleTypes.END_ROD, c.x + Math.cos(a) * 0.6, c.y, c.z + Math.sin(a) * 0.6,
					Math.cos(a) * 0.22, 0.03, Math.sin(a) * 0.22);
		}
		spray(level, ParticleTypes.FIREWORK, c.x, c.y, c.z, 14, 0.4, 0.4, 0.4, 0.12);
	}

	/** Efeito especial de "todas as facas disponíveis novamente": coluna de luz + anel de faíscas. */
	public static void ready(ServerLevel level, Entity player) {
		Vec3 f = player.position();
		for (int i = 0; i < 30; i++) {
			double a = i * (Math.PI * 2.0 / 30.0);
			dir(level, ParticleTypes.ELECTRIC_SPARK, f.x + Math.cos(a) * 1.2, f.y + 0.1, f.z + Math.sin(a) * 1.2,
					0.0, 0.18, 0.0);
		}
		for (int i = 0; i < 14; i++) {
			dir(level, ParticleTypes.END_ROD, f.x, f.y + 0.1 * i, f.z, 0.0, 0.12, 0.0);
		}
		spray(level, ParticleTypes.FIREWORK, f.x, f.y + 1.0, f.z, 16, 0.6, 0.8, 0.6, 0.1);
	}

	/** Fim da Ultimate: as facas restantes se dissipam em vento. */
	public static void end(ServerLevel level, Entity player) {
		Vec3 c = player.position().add(0, player.getBbHeight() * 0.55, 0);
		spray(level, ParticleTypes.CLOUD, c.x, c.y, c.z, 14, 0.5, 0.4, 0.5, 0.08);
		spray(level, ParticleTypes.POOF, c.x, c.y, c.z, 6, 0.4, 0.3, 0.4, 0.05);
	}
}
