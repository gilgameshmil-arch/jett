package com.valorantpack.fx;

import net.minecraft.world.phys.Vec3;

import java.util.Locale;

/** Quaternion mínimo (x, y, z, w) para orientar/girar os modelos 3D dos efeitos. */
public record Quat(double x, double y, double z, double w) {
	public static final Quat IDENTITY = new Quat(0, 0, 0, 1);
	public static final Vec3 UP = new Vec3(0, 1, 0);

	public static Quat axisAngle(double ax, double ay, double az, double radians) {
		double len = Math.sqrt(ax * ax + ay * ay + az * az);
		if (len < 1.0E-9) {
			return IDENTITY;
		}
		double s = Math.sin(radians / 2.0) / len;
		return new Quat(ax * s, ay * s, az * s, Math.cos(radians / 2.0));
	}

	public static Quat axisAngleDeg(double ax, double ay, double az, double degrees) {
		return axisAngle(ax, ay, az, Math.toRadians(degrees));
	}

	/** Menor rotação que leva o vetor {@code from} até {@code to}. */
	public static Quat fromTo(Vec3 from, Vec3 to) {
		Vec3 a = from.normalize();
		Vec3 b = to.normalize();
		double dot = a.dot(b);
		if (dot > 0.999999) {
			return IDENTITY;
		}
		if (dot < -0.999999) {
			Vec3 axis = a.cross(new Vec3(1, 0, 0));
			if (axis.lengthSqr() < 1.0E-6) {
				axis = a.cross(new Vec3(0, 0, 1));
			}
			return axisAngle(axis.x, axis.y, axis.z, Math.PI);
		}
		Vec3 c = a.cross(b);
		double n = Math.sqrt(c.lengthSqr() + (1 + dot) * (1 + dot));
		return new Quat(c.x / n, c.y / n, c.z / n, (1 + dot) / n);
	}

	/** Produto de Hamilton: {@code this * o} (aplica {@code o} primeiro, depois {@code this}). */
	public Quat mul(Quat o) {
		return new Quat(
				w * o.x + x * o.w + y * o.z - z * o.y,
				w * o.y - x * o.z + y * o.w + z * o.x,
				w * o.z + x * o.y - y * o.x + z * o.w,
				w * o.w - x * o.x - y * o.y - z * o.z);
	}

	/** Formato SNBT de lista de floats: [x,y,z,w]. */
	public String snbt() {
		return String.format(Locale.ROOT, "[%.5ff,%.5ff,%.5ff,%.5ff]", x, y, z, w);
	}
}
