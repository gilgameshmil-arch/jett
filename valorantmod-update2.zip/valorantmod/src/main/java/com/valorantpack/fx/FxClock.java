package com.valorantpack.fx;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import java.util.ArrayList;
import java.util.List;

/** Agendador de tarefas por tick do servidor (keyframes de animação, remoções atrasadas). */
public final class FxClock {
	private record Task(long at, Runnable run) {
	}

	private static final List<Task> TASKS = new ArrayList<>();
	private static long now;

	private FxClock() {
	}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(server -> tick());
	}

	/** Executa {@code run} daqui a {@code ticks} ticks (mínimo 1). */
	public static void after(int ticks, Runnable run) {
		TASKS.add(new Task(now + Math.max(1, ticks), run));
	}

	public static void clear() {
		TASKS.clear();
	}

	private static void tick() {
		now++;
		if (TASKS.isEmpty()) {
			return;
		}
		List<Runnable> due = new ArrayList<>();
		for (int i = TASKS.size() - 1; i >= 0; i--) {
			if (TASKS.get(i).at <= now) {
				due.add(0, TASKS.remove(i).run);
			}
		}
		for (Runnable r : due) {
			try {
				r.run();
			} catch (RuntimeException e) {
				com.valorantpack.ValorantMod.LOGGER.error("Erro em tarefa de efeito", e);
			}
		}
	}
}
