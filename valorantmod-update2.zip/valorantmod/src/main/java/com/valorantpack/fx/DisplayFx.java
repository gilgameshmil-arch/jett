package com.valorantpack.fx;

import com.valorantpack.ValorantMod;
import com.valorantpack.config.ModConfig;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityEvents;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Efeitos 3D de verdade: entidades vanilla {@code item_display} exibindo os modelos do mod
 * (assets/valorantmod/models/item/*.json) através do componente {@code item_model}.
 *
 * Por que item_display e não um renderizador próprio?
 *  - são entidades de verdade: o servidor as cria e TODOS os jogadores próximos as veem (multiplayer);
 *  - o cliente interpola transformação (escala/rotação/posição) sozinho -> animação suave sem tráfego por tick;
 *  - não dependem das APIs de renderização, que mudaram muito no 1.21.x.
 *
 * Criação e animação usam comandos (summon / data merge / tp) executados com permissão do servidor,
 * pois os setters de Display são privados. Cada efeito recebe UUID próprio (controlamos remoção) e a
 * tag {@link #TAG}; órfãos (ex.: servidor caiu) são descartados ao carregar o chunk.
 *
 * Todas as chamadas aceitam {@code null} como id (efeitos 3D desativados em {@code displayFx=false}).
 */
public final class DisplayFx {
	public static final String TAG = "valorantmod_fx";
	private static final Set<UUID> LIVE = new HashSet<>();

	private DisplayFx() {
	}

	/** Transformação: translação, rotação (esquerda), escala por eixo. */
	public record Xf(double tx, double ty, double tz, Quat rot, double sx, double sy, double sz) {
		public static Xf of(Quat rot, double scale) {
			return new Xf(0, 0, 0, rot, scale, scale, scale);
		}

		public static Xf of(Quat rot, double sx, double sy, double sz) {
			return new Xf(0, 0, 0, rot, sx, sy, sz);
		}

		public Xf withTranslation(double x, double y, double z) {
			return new Xf(x, y, z, rot, sx, sy, sz);
		}

		String snbt() {
			return String.format(Locale.ROOT,
					"{left_rotation:%s,right_rotation:[0f,0f,0f,1f],scale:[%.4ff,%.4ff,%.4ff],translation:[%.4ff,%.4ff,%.4ff]}",
					rot.snbt(), sx, sy, sz, tx, ty, tz);
		}
	}

	public static void init() {
		// Descarta efeitos "órfãos" que sobreviveram a um crash/reinício.
		ServerEntityEvents.ENTITY_LOAD.register((entity, level) -> {
			if (entity.getTags().contains(TAG) && !LIVE.contains(entity.getUUID())) {
				entity.discard();
			}
		});
	}

	public static boolean enabled() {
		return ModConfig.get().displayFx;
	}

	/** Cria um modelo 3D em {@code pos} (centro do modelo). Retorna o UUID ou null se desativado. */
	public static UUID spawn(ServerLevel level, Vec3 pos, String model, Xf xf, int teleportDuration) {
		if (!enabled()) {
			return null;
		}
		UUID id = UUID.randomUUID();
		LIVE.add(id);
		long msb = id.getMostSignificantBits();
		long lsb = id.getLeastSignificantBits();
		String nbt = String.format(Locale.ROOT,
				"{UUID:[I;%d,%d,%d,%d],Tags:[\"%s\"],"
						+ "item:{id:\"minecraft:stick\",count:1,components:{\"minecraft:item_model\":\"%s:%s\"}},"
						+ "item_display:\"none\",billboard:\"fixed\",brightness:{sky:15,block:15},"
						+ "view_range:%.2ff,shadow_radius:0.0f,shadow_strength:0.0f,"
						+ "teleport_duration:%d,start_interpolation:0,interpolation_duration:0,transformation:%s}",
				(int) (msb >> 32), (int) msb, (int) (lsb >> 32), (int) lsb, TAG,
				ValorantMod.MOD_ID, model, ModConfig.get().fxViewRange, Math.max(0, Math.min(59, teleportDuration)),
				xf.snbt());
		run(level, String.format(Locale.ROOT, "summon minecraft:item_display %.4f %.4f %.4f %s", pos.x, pos.y, pos.z, nbt));
		return id;
	}

	/** Anima a transformação até {@code xf} ao longo de {@code durationTicks} (interpolação feita no cliente). */
	public static void animate(ServerLevel level, UUID id, Xf xf, int durationTicks) {
		if (id == null) {
			return;
		}
		run(level, String.format(Locale.ROOT,
				"data merge entity %s {start_interpolation:0,interpolation_duration:%d,transformation:%s}",
				id, Math.max(1, durationTicks), xf.snbt()));
	}

	/** Move a entidade (com suavização de {@code teleport_duration} definido na criação). */
	public static void teleport(ServerLevel level, UUID id, Vec3 pos) {
		if (id == null) {
			return;
		}
		run(level, String.format(Locale.ROOT, "tp %s %.4f %.4f %.4f", id, pos.x, pos.y, pos.z));
	}

	public static void remove(ServerLevel level, UUID id) {
		if (id == null) {
			return;
		}
		LIVE.remove(id);
		Entity e = level.getEntity(id);
		if (e != null) {
			e.discard();
		}
	}

	private static void run(ServerLevel level, String command) {
		MinecraftServer server = level.getServer();
		CommandSourceStack source = server.createCommandSourceStack().withLevel(level).withSuppressedOutput();
		server.getCommands().performPrefixedCommand(source, command);
	}
}
