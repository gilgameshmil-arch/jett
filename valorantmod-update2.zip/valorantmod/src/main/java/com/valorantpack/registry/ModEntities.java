package com.valorantpack.registry;

import com.valorantpack.ValorantMod;
import com.valorantpack.entity.BladeKnifeEntity;
import com.valorantpack.entity.BladeOrbitEntity;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public final class ModEntities {
	/** Faca arremessada (projétil). */
	public static final EntityType<BladeKnifeEntity> BLADE_KNIFE = register("blade_knife",
			EntityType.Builder.<BladeKnifeEntity>of(BladeKnifeEntity::new, MobCategory.MISC)
					.sized(0.3F, 0.3F)
					.clientTrackingRange(10)
					.updateInterval(1)
					.noSave()
					.noSummon());

	/** Faca em órbita ao redor do jogador (apenas visual; posição controlada pelo servidor). */
	public static final EntityType<BladeOrbitEntity> BLADE_ORBIT = register("blade_orbit",
			EntityType.Builder.<BladeOrbitEntity>of(BladeOrbitEntity::new, MobCategory.MISC)
					.sized(0.25F, 0.25F)
					.clientTrackingRange(8)
					.updateInterval(Integer.MAX_VALUE) // posição calculada nos dois lados (ver OrbitMath)
					.noSave()
					.noSummon());

	private ModEntities() {
	}

	private static <T extends Entity> EntityType<T> register(String name, EntityType.Builder<T> builder) {
		Identifier id = ValorantMod.id(name);
		ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, id);
		return Registry.register(BuiltInRegistries.ENTITY_TYPE, id, builder.build(key));
	}

	public static void init() {
		// Força o carregamento da classe (e portanto o registro das entidades).
	}
}
