package com.valorantpack.registry;

import com.valorantpack.ValorantMod;
import com.valorantpack.item.BladeStormItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

import java.util.function.Function;

/**
 * Registro de itens. Futuras armas (Vandal, Phantom) e facas Champions devem ser
 * registradas aqui (ou em classes irmãs chamadas por ValorantMod#onInitialize).
 */
public final class ModItems {
	/** Item da Ultimate: botão direito ativa (ou lança uma faca se já estiver ativa). */
	public static final Item BLADE_STORM = register("blade_storm", BladeStormItem::new, new Item.Properties().stacksTo(1));

	/** Item "visual": é só o modelo 3D usado para renderizar as facas em órbita e em voo. */
	public static final Item BLADE_STORM_KNIFE = register("blade_storm_knife", Item::new, new Item.Properties());

	private ModItems() {
	}

	private static <T extends Item> T register(String name, Function<Item.Properties, T> factory, Item.Properties props) {
		Identifier id = ValorantMod.id(name);
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
		return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(props.setId(key)));
	}

	public static void init() {
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(entries -> entries.accept(BLADE_STORM));
	}
}
