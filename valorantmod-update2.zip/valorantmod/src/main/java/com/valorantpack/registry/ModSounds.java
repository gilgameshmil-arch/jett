package com.valorantpack.registry;

import com.valorantpack.ValorantMod;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

/**
 * Eventos de som do mod. Os arquivos de áudio ficam mapeados em
 * assets/valorantmod/sounds.json. Na etapa 1 apontam para eventos de som do
 * Minecraft (placeholders); para usar sons próprios, troque cada entrada do
 * sounds.json por {"name": "valorantmod:caminho/do_arquivo"} e coloque o .ogg em
 * assets/valorantmod/sounds/. O código Java não precisa mudar.
 */
public final class ModSounds {
	public static final SoundEvent ACTIVATE = register("blade_storm.activate");
	public static final SoundEvent WIND = register("blade_storm.wind");
	public static final SoundEvent KNIFE_APPEAR = register("blade_storm.knife_appear");
	public static final SoundEvent THROW = register("blade_storm.throw");
	public static final SoundEvent HIT = register("blade_storm.hit");
	public static final SoundEvent HEADSHOT = register("blade_storm.headshot");
	public static final SoundEvent REFRESH = register("blade_storm.refresh");
	public static final SoundEvent READY = register("blade_storm.ready");
	public static final SoundEvent END = register("blade_storm.end");
	public static final SoundEvent CLOUD_THROW = register("cloudburst.throw");
	public static final SoundEvent CLOUD_BURST = register("cloudburst.burst");
	public static final SoundEvent TAILWIND = register("tailwind.dash");
	public static final SoundEvent UPDRAFT = register("updraft.launch");

	private ModSounds() {
	}

	private static SoundEvent register(String path) {
		Identifier id = ValorantMod.id(path);
		return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
	}

	public static void init() {
		// Força o carregamento da classe (e portanto o registro dos sons).
	}
}
