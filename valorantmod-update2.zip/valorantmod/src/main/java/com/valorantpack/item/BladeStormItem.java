package com.valorantpack.item;

import com.valorantpack.ability.AbilityManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/**
 * Jett's Blade Storm. Botão direito: ativa a Ultimate; com ela ativa, lança uma faca.
 * As teclas configuráveis (ModKeys) fazem o mesmo sem precisar segurar o item.
 */
public class BladeStormItem extends Item {
	public BladeStormItem(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (!level.isClientSide() && player instanceof ServerPlayer sp) {
			AbilityManager.onItemUse(sp);
		}
		return InteractionResult.SUCCESS;
	}
}
