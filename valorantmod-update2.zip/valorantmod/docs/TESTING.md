# Checklist de teste manual (nada abaixo foi executado ainda)

Compile (`./gradlew build`) e marque cada item. Teste em **singleplayer** e em **servidor dedicado com 2 jogadores**.

## Ativação
- [ ] Botão direito com o item ativa; HUD "BLADE STORM" aparece.
- [ ] Tecla X ativa (com item no inventário); sem item mostra a mensagem.
- [ ] 5 facas surgem uma a uma, em órbita; partículas de vento/energia visíveis.
- [ ] Outro jogador vê as facas orbitando.

## Lançamento
- [ ] R/botão direito lança 1 faca na direção da mira; HUD cai de 5 para 4 (a de maior índice some).
- [ ] V lança as restantes em rajada com leve dispersão.
- [ ] Faca não atravessa parede; some ao bater em bloco.
- [ ] Dano e headshot corretos; não fere o próprio dono; `damagePlayers=false` poupa jogadores.

## Recuperação
- [ ] Abater um mob com faca restaura as 5, com efeito "refresh" e depois "ready".
- [ ] Abate pela última faca (remaining=0) ainda recupera antes de a Ultimate terminar.

## Fim e recarga
- [ ] Sem facas e nada em voo: a Ultimate termina; HUD mostra "RECHARGING".
- [ ] Reativar durante a recarga é bloqueado com mensagem.
- [ ] Morrer, desconectar, trocar de dimensão: sem entidades órfãs; órbita reaparece após trocar de dimensão.

## Config / teclas
- [ ] `config/valorantmod.json` criado; alterar `knifeCount`, `knifeDamage`, `ultimateCooldownSeconds` surte efeito.
- [ ] Teclas aparecem em Controles e podem ser remapeadas.

## Se algo falhar
Envie o log do Gradle (compilação) ou `logs/latest.log` (runtime).

---

# Checklist — Atualização 2 (nada abaixo foi executado ainda)

Teste em singleplayer **e** em servidor dedicado com 2 jogadores (um dá os comandos, o outro observa).

## Faca 3D
- [ ] `/give @s valorantmod:blade_storm`: ícone no inventário é a faca 3D (inclinada, não achatada).
- [ ] Na mão (1ª e 3ª pessoa) a faca fica bem posicionada → senão ajuste `display` no Blockbench.
- [ ] Facas em órbita/voo aparecem com volume (lembre: elas giram para a câmera).

## Cloudburst (G)
- [ ] Orbe voa e estoura em bloco/alcance máximo; esfera de fumaça **redonda** aparece.
- [ ] Fumaça gira (casca externa e interna em sentidos opostos) e há partículas tangentes.
- [ ] O OUTRO jogador vê a esfera (e a orbe em voo).
- [ ] Some gradualmente (externa encolhe, depois a interna); nenhuma entidade sobra (`/kill @e[type=item_display]` só para conferir).
- [ ] Recarga no HUD; segunda tentativa durante a recarga é recusada.

## Tailwind (C)
- [ ] Dash começa no mesmo tick da tecla (sem atraso perceptível), ~13 blocos, direção segue W/A/S/D.
- [ ] Túnel de vento acompanha e gira; anéis ficam no caminho e somem; linhas de velocidade na tela.
- [ ] O outro jogador vê o túnel/anéis e o movimento sem "puxões" (rubber-band).
- [ ] Recusado pelo servidor (recarga) cancela o dash local.

## Updraft (Z)
- [ ] Sobe ~6 blocos; hélice 3D sobe junto; anéis de ar ficam para trás; sem dano de queda.
- [ ] O outro jogador vê a coluna de vento.

## Geral
- [ ] `displayFx=false` desliga os modelos 3D e mantém só partículas.
- [ ] Sair/entrar no servidor durante os efeitos não deixa entidades órfãs.
- [ ] Log sem erros de comando (`summon`/`data merge`/`tp`) em `logs/latest.log`.
