# Guia de expansão (Etapa 2+)

Ponto de partida: tudo que for novo entra por **registro + pacote + cliente**, sem mexer na Blade Storm.

## Armas (Vandal / Phantom, padrão e Champions — designs originais)
- Pacote `weapon/`: `WeaponItem` (stats: dano, cadência, pente, recarga, dispersão), `WeaponState` (munição/recarga por jogador no servidor).
- Disparo: hitscan no servidor (mesmo padrão de `AbilityManager.aimPoint`), pacote C2S `WeaponActionPayload` (FIRE, RELOAD, INSPECT).
- Variantes Champions = novos itens/modelos que reutilizam a mesma classe com outros stats e texturas.

## Facas Champions (Karambit, Butterfly, Kunai, Blade, Melee — modelos próprios)
- Pacote `knife/`: `KnifeItem` (ataque, inspeção). Modelos JSON próprios por faca em `models/item/`.

## Animações (equipar, guardar, disparar, recarregar, inspecionar)
- Cliente: `client/animation/` com um `AnimationController` por item, dirigido por `ClientAbilityState`-like (estado por item) + tempo do cliente.
- Primeira pessoa: Fabric não expõe API estável; use mixin em `ItemInHandRenderer` ou modelos com `display` + transformações por estado.

## Sons e partículas próprios
- Sons: substituir os mapeamentos de `sounds.json` por `.ogg` em `assets/valorantmod/sounds/`.
- Partículas: registrar `SimpleParticleType` em `registry/ModParticles` e centralizar o uso em `Fx`.

## Novas habilidades
Criar classe análoga a `AbilityManager`, reutilizar `AbilitySyncPayload` (ou um payload por habilidade) e `ModKeys`.
