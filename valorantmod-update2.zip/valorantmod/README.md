# Valorant Ultimate Weapon Pack — Blade Storm + Mobilidade da Jett (Fabric, Minecraft 1.21.11)

Mod original inspirado na Ultimate da Jett. **Todos os assets são originais** (gerados por script);
nenhum arquivo do VALORANT foi usado.

## ⚠️ Estado real desta entrega (leia primeiro)

| Item | Status |
|---|---|
| Código-fonte completo (Java, JSON, lang, sounds.json) | ✅ escrito |
| Texturas e modelos 3D | ✅ gerados por `tools/generate_fx_assets.py` (arte original procedural, **não** HD pintada à mão) |
| **Compilação** | ❌ **NÃO testada** — o ambiente onde escrevi não tem rede (sem Gradle/Loom/Minecraft) |
| **Execução no jogo / multiplayer** | ❌ **NÃO testada** |
| `.jar` pronto | ❌ **não existe** — você precisa compilar (passos abaixo) |
| Sons | ⚠️ mapeados para sons **vanilla** (placeholder); sem áudio gravado |
| `gradle-wrapper.jar` / `gradlew` | ❌ ausentes (não dá para baixar aqui) |

Como a API do Minecraft 1.21.11 mudou bastante e escrevi sem poder compilar, **espere alguns erros de
compilação** (nomes/assinaturas). Veja "Pontos de maior risco" e me envie o log do Gradle: corrijo.

Versões: Fabric API `0.141.1+1.21.11` confirmada. Loader `0.18.4` e Loom `1.14-SNAPSHOT` **não confirmados** — ajuste
`gradle.properties` conforme o template oficial (https://fabricmc.net/develop/template) se necessário.

## Compilar

Requisitos: JDK 21, Gradle 9.x (ou o wrapper).

```bash
cd valorantmod
python3 tools/generate_assets.py     # já foi executado; rode de novo se editar a arte
gradle wrapper --gradle-version 9.2.1  # cria gradlew (só na 1ª vez; ou copie o wrapper do fabric-example-mod)
./gradlew build
```
O jar sai em `build/libs/valorantmod-0.1.0.jar`. Teste em dev: `./gradlew runClient` / `./gradlew runServer`.

## Instalar
1. Fabric Loader (>= 0.18.1) para Minecraft 1.21.11.
2. **Fabric API** na pasta `mods/`.
3. `valorantmod-0.1.0.jar` em `mods/` (cliente **e** servidor).

Dependências: apenas Fabric API. TACZ **não** é usado nesta etapa.

## Como jogar
- Pegue **Jett's Blade Storm** (aba Combate do criativo, ou `/give @s valorantmod:blade_storm`).
- **Ativar:** botão direito com o item, ou tecla **X** (configurável).
- Cinco facas materializam uma a uma em órbita ao seu redor.
- **Lançar uma:** botão direito ou **R**. **Lançar todas em rajada:** **V**.
- Abater alguém **com uma faca** restaura as cinco. Sem facas e nada em voo: a Ultimate termina e começa a recarga.
- Teclas: Opções › Controles › "Valorant Pack — Habilidades".

## Configuração
`config/valorantmod.json` (criado na 1ª execução): quantidade de facas, dano, multiplicador de headshot, velocidade,
vida útil, intervalos, dispersão da rajada, recarga, recuperação por abate, dano a jogadores, exigir item para a tecla,
duração máxima, raio/velocidade da órbita e densidade de partículas. Valores inválidos são corrigidos ao carregar.

## Arquitetura
```
src/main   (comum: servidor + cliente)
  ability/   AbilityManager (lógica autoritativa), BladeStormState
  entity/    BladeKnifeEntity (projétil), BladeOrbitEntity (visual), OrbitMath
  item/      BladeStormItem
  network/   payloads C2S (ação) e S2C (estado/HUD)
  registry/  ModItems, ModEntities, ModSounds
  fx/        Fx (partículas + sons centralizados)
  config/    ModConfig
src/client   (só cliente)
  client/    ValorantModClient, ModKeys, BladeStormHud, ClientAbilityState
tools/generate_assets.py
```
Multiplayer: o cliente só envia pedidos; o servidor valida item, recarga e intervalo, e devolve o estado.
A órbita é calculada igual nos dois lados a partir do tempo do mundo (sem tráfego por tick).
Veja `docs/EXPANSION.md` para a Etapa 2 e `docs/TESTING.md` para o checklist.

## Pontos de maior risco de compilação (não verificados contra 1.21.11)
- Sobrescritas de `ThrowableItemProjectile` (`getDefaultItem`, `onHitEntity`, `onHitBlock`).
- `Entity.hurtServer(ServerLevel, DamageSource, float)` e `DamageSources.thrown`.
- `ValueInput` / `ValueOutput` nas entidades.
- `Level.playSound(null, ...)` e `ServerLevel.sendParticles` (assinaturas).
- `HudElementRegistry`, `VanillaHudElements`, `KeyMapping.Category.register`.
- `EntityRendererRegistry.register` + `ThrownItemRenderer` (construtor).
- `ServerPlayer.level()`, `MinecraftServer.getTickCount()`, `LivingEntity.invulnerableTime`.
- ID do plugin Loom (`fabric-loom` vs `net.fabricmc.fabric-loom-remap`).

## Limitações conhecidas
- A faca em órbita/voo usa o renderizador de item vanilla (sprite/modelo do item), não um renderizador próprio com rotação de lâmina.
- Texturas procedurais simples; sons são placeholders.
- Design **original**: não reproduz o visual oficial da Jett/VALORANT.

---

# Atualização 2 — Gráficos 3D e habilidades de mobilidade

Adicionado: faca 3D nova, **Cloudburst**, **Tailwind (dash)** e **Updraft**, com efeitos 3D próprios.

## O que mudou
| Item | Como é feito |
|---|---|
| **Faca 3D** | `models/item/blade_storm_knife.json`: 27 cuboides (lâmina curva de 12 passos, guarda com asas, cabo com bandas, pomo com joia, halo de vento). Usada na mão (1ª/3ª pessoa), inventário (GUI), chão e nas facas em órbita/voo. |
| **Cloudburst (tecla G)** | Orbe lançada → esfera de fumaça 3D: 2 cascas (`cloud_shell_outer/inner`, discos cruzados com textura de fumaça) girando em sentidos opostos, "respirando", e encolhendo em etapas até sumir. Partículas tangenciais reforçam o giro. |
| **Tailwind (tecla C)** | Dash de `dashSpeed` 1.9 blocos/tick por 7 ticks, **aplicado no cliente no mesmo tick da tecla**. Túnel de vento 3D que acompanha e gira, anéis que se expandem no caminho, onda de choque e hélice de partículas. Linhas de velocidade na tela. |
| **Updraft (tecla Z)** | Impulso vertical (~6 blocos), coluna helicoidal 3D subindo com o jogador, anéis de ar deixados no caminho, ondas de choque no chão, sem dano de queda. |
| **Efeitos 3D** | Entidades vanilla `item_display` (criadas pelo servidor) exibindo os modelos do mod via componente `item_model` → visíveis a todos os jogadores; animação interpolada no cliente. |

**Teclas:** E e Q do Valorant colidem com Inventário/Largar item do Minecraft, então os padrões são **G / C / Z**. Troque em Controles.

**Config nova** (`config/valorantmod.json`): `cloudburstCooldownSeconds`, `cloudRadius`, `cloudDurationTicks`, `cloudThrowSpeed`, `cloudMaxRange`, `tailwindCooldownSeconds`, `dashSpeed`, `dashTicks`, `updraftCooldownSeconds`, `updraftVelocity`, `updraftFallProtectionTicks`, `displayFx`, `fxViewRange`.
`dashSpeed`, `dashTicks` e `updraftVelocity` são lidos pelo **cliente** (o movimento é do cliente, como no vanilla); recargas e efeitos visuais vêm do servidor.

## Blockbench
Os modelos são JSON de item vanilla: abra em **Blockbench → File → Open Model** para refinar (`tools/generate_fx_assets.py` os regenera; se editar no Blockbench, não rode o gerador por cima). `python3 tools/preview_models.py <modelo> saida.png` gera uma prévia aproximada.

## ⚠️ O que foi e o que NÃO foi verificado
**Executado de verdade aqui:**
- Validação estrutural dos 7 modelos (UVs 0–16, rotações permitidas, texturas existentes, definições de item) e dos 20 JSONs.
- Teste unitário da matemática de quaternion que orienta o túnel/anéis do dash (8 direções + giro + composição): passou.
- Geração e conferência do formato dos comandos `summon` / `data merge` / `tp` (texto).
- `javac` sobre todo o código: sem erros de **sintaxe** (erros de símbolo existem porque faltam as libs do Minecraft).
- Pré-visualização aproximada da faca, da esfera e da hélice (projeção própria, não o renderizador do Minecraft).

**NÃO executado (não há Minecraft aqui):** compilação contra 1.21.11, abrir o jogo, ver os efeitos, singleplayer, **multiplayer**. Portanto **não** posso afirmar que os efeitos funcionam no jogo ou entre jogadores. A lógica foi desenhada para multiplayer (servidor cria as entidades; cliente só pede e prevê movimento), mas isso é projeto, não teste. Use `docs/TESTING.md`.

## Riscos conhecidos desta atualização
- **Comandos como API de efeitos:** `DisplayFx` usa `server.getCommands().performPrefixedCommand` com permissão de servidor; confira assinaturas no 1.21.11. Se um comando falhar, o efeito 3D some (o log registra) e só ficam as partículas.
- **Transparência:** as texturas de fumaça usam alfa com dithering (funciona mesmo se o item for renderizado como "cutout"); se o jogo renderizar translúcido, ficará mais macio. Pode ser preciso ajustar a olho.
- **Display transforms da faca** (mão/inventário) estão estimados: provavelmente precisam de ajuste fino no Blockbench (aba Display).
- **Faca em voo/órbita:** usa `ThrownItemRenderer` (vanilla), que gira o modelo para a câmera; ela **não aponta na direção do voo**. Um renderizador próprio resolveria, mas depende da API de renderização do 1.21.11 que não pude verificar.
- **Cloudburst não bloqueia visão de verdade** (é visual: por estar dentro da esfera os discos cobrem boa parte da tela, mas não há mecânica de bloqueio de linha de visão).
- **Partículas:** continuam vanilla (CLOUD, END_ROD, ELECTRIC_SPARK) como reforço. Partículas com textura própria exigem registro de ParticleType + factory no cliente (API não verificada); os efeitos principais são os modelos 3D próprios.
- Entidades `item_display` órfãs (queda do servidor) são descartadas no carregamento do chunk via `ServerEntityEvents.ENTITY_LOAD`.
