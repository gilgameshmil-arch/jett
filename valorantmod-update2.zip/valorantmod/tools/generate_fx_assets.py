#!/usr/bin/env python3
"""
Gera os assets 3D e as texturas dos efeitos (originais, procedurais):

  Faca (Blade Storm)  : models/item/blade_storm_knife.json  (+ textura atlas 64x64)
  Cloudburst          : cloud_shell_outer / cloud_shell_inner / cloud_orb
  Tailwind / Updraft  : wind_ring / wind_tunnel / wind_spiral
  Definicoes de item  : items/<nome>.json  (usadas via componente item_model nos item_display)

Tudo e composto de cuboides (modelos de item vanilla), entao abre no Blockbench
(File > Open Model) para refinar. UVs seguem a convencao do Minecraft: 0..16 sobre a textura inteira.

Uso:  python3 tools/generate_fx_assets.py            # gera e valida
      python3 tools/generate_fx_assets.py --check    # so valida
"""
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import generate_assets as base  # noqa: E402  (write_png, lerp_col, paleta)

ASSETS = base.ASSETS
TEX_DIR = os.path.join(ASSETS, "textures", "item")
FX_TEX_DIR = os.path.join(TEX_DIR, "fx")
MODEL_DIR = os.path.join(ASSETS, "models", "item")
ITEM_DIR = os.path.join(ASSETS, "items")
NS = "valorantmod"

ALLOWED_ANGLES = (-45.0, -22.5, 0.0, 22.5, 45.0)

# ======================================================================== utilidades de ruido

def _hash(ix, iy, seed):
    n = (ix * 374761393 + iy * 668265263 + seed * 144665) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    n ^= n >> 16
    return (n & 0xFFFF) / 65535.0


def _smooth(t):
    return t * t * (3 - 2 * t)


def vnoise(x, y, seed):
    ix, iy = math.floor(x), math.floor(y)
    fx, fy = _smooth(x - ix), _smooth(y - iy)
    a, b = _hash(ix, iy, seed), _hash(ix + 1, iy, seed)
    c, d = _hash(ix, iy + 1, seed), _hash(ix + 1, iy + 1, seed)
    return (a + (b - a) * fx) + ((c + (d - c) * fx) - (a + (b - a) * fx)) * fy


def fbm(x, y, seed, octaves=4):
    v, amp, tot = 0.0, 0.5, 0.0
    for o in range(octaves):
        v += amp * vnoise(x, y, seed + o * 17)
        tot += amp
        x *= 2.0
        y *= 2.0
        amp *= 0.5
    return v / tot


BAYER = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]


def dither_alpha(a, x, y, levels=(0, 90, 170, 255)):
    """Alfa quantizado com dithering: funciona mesmo se o item for renderizado como 'cutout'."""
    v = a + (BAYER[y % 4][x % 4] / 15.0 - 0.5) * 0.30
    if v < 0.30:
        return levels[0]
    if v < 0.50:
        return levels[1]
    if v < 0.70:
        return levels[2]
    return levels[3]


def blank(w, h):
    return [[(0, 0, 0, 0) for _ in range(w)] for _ in range(h)]

# ======================================================================== texturas de fumaca / vento

def smoke_texture(seed, light, dark, density=1.0, size=64, edge_start=0.55):
    px = blank(size, size)
    c = (size - 1) / 2.0
    for y in range(size):
        for x in range(size):
            r = math.hypot(x - c, y - c) / (size / 2.0)
            mask = 1.0 - base.lerp(0.0, 1.0, _smooth(max(0.0, min(1.0, (r - edge_start) / (1.0 - edge_start)))))
            n = fbm(x * 0.11, y * 0.11, seed)
            wisp = fbm(x * 0.05 + 7.3, y * 0.05 - 3.1, seed + 99)
            a = mask * (0.25 + 1.05 * n * density) * (0.7 + 0.5 * wisp)
            col = base.lerp_col(dark, light, 0.25 + 0.9 * n - 0.25 * r)
            al = dither_alpha(min(1.0, a), x, y)
            if al:
                px[y][x] = (col[0], col[1], col[2], al)
    return size, size, px


def ring_texture(seed, size=64):
    px = blank(size, size)
    c = (size - 1) / 2.0
    for y in range(size):
        for x in range(size):
            dx, dy = x - c, y - c
            r = math.hypot(dx, dy) / (size / 2.0)
            if r < 0.55 or r > 1.0:
                continue
            ang = math.atan2(dy, dx)
            # dois arcos "cometa": cabeca brilhante e cauda que desaparece
            arc = 0.0
            for head in (0.0, math.pi):
                d = (ang - head + math.pi) % (2 * math.pi) - math.pi
                if d <= 0.0:
                    arc = max(arc, math.exp(d * 1.1))
            radial = 1.0 - abs((r - 0.78) / 0.23)
            streak = fbm(ang * 3.0 + r * 9.0, r * 14.0, seed)
            a = max(0.0, radial) * (0.25 + 0.95 * arc) * (0.55 + 0.7 * streak)
            col = base.lerp_col((140, 225, 250), (255, 255, 255), arc * 0.9)
            al = dither_alpha(min(1.0, a), x, y)
            if al:
                px[y][x] = (col[0], col[1], col[2], al)
    return size, size, px


def streak_texture(seed, w=32, h=32):
    px = blank(w, h)
    for y in range(h):
        for x in range(w):
            u = (x + 0.5) / w
            v = (y + 0.5) / h
            across = math.exp(-((u - 0.5) / 0.22) ** 2)
            along = math.sin(math.pi * v) ** 0.7
            n = fbm(x * 0.2, y * 0.08, seed)
            a = across * along * (0.5 + 0.8 * n)
            col = base.lerp_col((120, 215, 245), (255, 255, 255), across)
            al = dither_alpha(min(1.0, a), x, y)
            if al:
                px[y][x] = (col[0], col[1], col[2], al)
    return w, h, px


def puff_texture(seed, size=16):
    px = blank(size, size)
    c = (size - 1) / 2.0
    for y in range(size):
        for x in range(size):
            r = math.hypot(x - c, y - c) / (size / 2.0)
            n = fbm(x * 0.35, y * 0.35, seed)
            a = max(0.0, 1.0 - r * r) * (0.55 + 0.7 * n)
            col = base.lerp_col((130, 220, 250), (255, 255, 255), 1.0 - r)
            al = dither_alpha(min(1.0, a * 1.1), x, y)
            if al:
                px[y][x] = (col[0], col[1], col[2], al)
    return size, size, px

# ======================================================================== atlas da faca

REG = {  # regiao -> origem em pixels no atlas 64x64 (cada uma 16x16)
    "steel": (0, 0), "glow": (16, 0), "wrap": (32, 0), "guard": (48, 0),
    "pommel": (0, 16), "edge": (16, 16), "gem": (32, 16),
}


def knife_texture():
    W = H = 64
    px = blank(W, H)

    def put(rx, ry, fn):
        for y in range(16):
            for x in range(16):
                c = fn(x, y)
                px[ry + y][rx + x] = (c[0], c[1], c[2], 255)

    # lamina de aco: gradiente (ponta mais clara), veio central (fuller) ciano, brilho fino nas bordas
    def steel(x, y):
        t = 1.0 - y / 15.0          # y=0 e a ponta (topo)
        c = base.lerp_col((46, 58, 72), (150, 175, 195), 0.25 + 0.6 * t)
        n = vnoise(x * 0.9, y * 0.25, 5)
        c = base.lerp_col(c, (200, 220, 235), 0.12 * n)
        if 7 <= x <= 8:
            c = base.lerp_col(c, base.CYAN, 0.85)
        elif x in (6, 9):
            c = base.lerp_col(c, base.CYAN, 0.30)
        if x in (0, 15):
            c = base.lerp_col(c, base.WHITE, 0.5)
        return c
    put(*REG["steel"], steel)

    def edge(x, y):
        t = 1.0 - y / 15.0
        return base.lerp_col(base.CYAN, base.WHITE, 0.4 + 0.6 * t)
    put(*REG["edge"], edge)

    def glow(x, y):
        n = fbm(x * 0.3, y * 0.3, 21)
        c = base.lerp_col(base.TEAL, base.WHITE, 0.35 + 0.65 * n)
        if (x + y) % 5 == 0:
            c = base.lerp_col(c, base.WHITE, 0.35)
        return c
    put(*REG["glow"], glow)

    def wrap(x, y):
        c = base.NAVY
        if (x + y) % 4 in (0, 1):
            c = base.lerp_col(base.NAVY, base.DEEP, 0.8)
        if (x - y) % 8 == 0:
            c = base.lerp_col(c, base.CYAN, 0.35)
        return c
    put(*REG["wrap"], wrap)

    def guard(x, y):
        t = y / 15.0
        c = base.lerp_col(base.CYAN, base.TEAL, t)
        if y in (0, 15) or x in (0, 15):
            c = base.lerp_col(c, base.WHITE, 0.5)
        if 6 <= y <= 9 and x % 4 < 2:
            c = base.RED
        return c
    put(*REG["guard"], guard)

    def pommel(x, y):
        c = base.lerp_col(base.STEEL_HI, base.STEEL, y / 15.0)
        if (x + y) % 6 == 0:
            c = base.lerp_col(c, base.CYAN, 0.3)
        return c
    put(*REG["pommel"], pommel)

    def gem(x, y):
        d = math.hypot(x - 7.5, y - 7.5) / 8.0
        return base.lerp_col((255, 200, 205), base.RED, min(1.0, d * 1.2))
    put(*REG["gem"], gem)
    return W, H, px

# ======================================================================== construcao de modelos

def uvr(rx, ry, u0, v0, u1, v1):
    """Pixels do atlas (regiao + 0..16) -> UV 0..16 do Minecraft (atlas 64 => /4)."""
    def cl(v):
        return max(0.0, min(16.0, v))
    return [round((rx + cl(u0)) / 4.0, 4), round((ry + cl(v0)) / 4.0, 4),
            round((rx + cl(u1)) / 4.0, 4), round((ry + cl(v1)) / 4.0, 4)]


def el(frm, to, region, name, rot=None, shade=True):
    rx, ry = REG[region]
    x0, y0, z0 = frm
    x1, y1, z1 = to
    side = uvr(rx, ry, x0, 16 - y1, x1, 16 - y0)
    end = uvr(rx, ry, z0, 16 - y1, z1, 16 - y0)
    top = uvr(rx, ry, x0, z0, x1, z1)
    e = {
        "name": name, "from": [round(v, 3) for v in frm], "to": [round(v, 3) for v in to],
        "faces": {
            "north": {"uv": side, "texture": "#0"}, "south": {"uv": side, "texture": "#0"},
            "east": {"uv": end, "texture": "#0"}, "west": {"uv": end, "texture": "#0"},
            "up": {"uv": top, "texture": "#0"}, "down": {"uv": top, "texture": "#0"},
        },
    }
    if rot:
        e["rotation"] = {"angle": rot[0], "axis": rot[1], "origin": list(rot[2])}
    if not shade:
        e["shade"] = False
    return e


def knife_model():
    els = []
    # ---- pomo: bloco + joia + aro
    els.append(el((6.1, 0.0, 6.9), (9.9, 1.5, 9.1), "pommel", "pommel"))
    els.append(el((7.3, 0.4, 9.1), (8.7, 1.2, 9.4), "gem", "gem_front"))
    els.append(el((7.3, 0.4, 6.6), (8.7, 1.2, 6.9), "gem", "gem_back"))
    # ---- cabo com bandas de couro
    els.append(el((7.2, 1.5, 7.2), (8.8, 5.3, 8.8), "wrap", "grip"))
    for i, y in enumerate((2.0, 3.2, 4.4)):
        els.append(el((6.9, y, 6.9), (9.1, y + 0.55, 9.1), "guard", f"ring_{i}"))
    # ---- guarda com asas de vento (inclinacao simetrica)
    els.append(el((5.4, 5.3, 7.0), (10.6, 6.1, 9.0), "guard", "guard"))
    els.append(el((3.4, 5.2, 7.2), (5.5, 6.0, 8.8), "guard", "guard_wing_l", rot=(22.5, "z", (5.4, 5.6, 8.0))))
    els.append(el((10.5, 5.2, 7.2), (12.6, 6.0, 8.8), "guard", "guard_wing_r", rot=(-22.5, "z", (10.6, 5.6, 8.0))))
    # ---- lamina curva (varre para +x), secao em losango: espinha + chanfros
    # perfil de folha (mais larga perto de 30% do comprimento) com varredura para +x, em 12 passos finos
    n_seg, y_base, y_tip = 12, 6.1, 15.9
    step = (y_tip - y_base) / n_seg
    for i in range(n_seg):
        t0, t1 = i / n_seg, (i + 1) / n_seg
        tm = (t0 + t1) / 2.0
        hw = 0.25 + 1.95 * math.sin(math.pi * min(1.0, tm ** 0.75)) ** 0.9
        dx = 2.8 * tm ** 2.2
        y0, y1 = y_base + i * step, y_base + (i + 1) * step
        cx = 8.0 + dx
        sp = 0.55 * (1.0 - 0.5 * tm)
        zt = 0.38 * (1.0 - 0.6 * tm)
        els.append(el((cx - sp, y0, 8.0 - 0.95 * (1 - 0.4 * tm)), (cx + sp, y1, 8.0 + 0.95 * (1 - 0.4 * tm)),
                      "steel", f"spine_{i}", shade=False))
        els.append(el((cx - hw, y0, 8.0 - zt), (cx + hw, y1, 8.0 + zt), "edge", f"bevel_{i}", shade=False))
    # ---- halo de vento: dois quadrados girados 45 graus = anel octogonal fino ao redor da lamina
    ring_y, rr, th = 9.4, 3.3, 0.22
    for k, ang in enumerate((0.0, 45.0)):
        o = (8.0, ring_y, 8.0)
        r = (ang, "y", o) if ang else None
        els.append(el((8 - rr, ring_y, 8 - rr), (8 + rr, ring_y + th, 8 - rr + 0.45), "glow", f"halo{k}_n", rot=r, shade=False))
        els.append(el((8 - rr, ring_y, 8 + rr - 0.45), (8 + rr, ring_y + th, 8 + rr), "glow", f"halo{k}_s", rot=r, shade=False))
        els.append(el((8 - rr, ring_y, 8 - rr + 0.45), (8 - rr + 0.45, ring_y + th, 8 + rr - 0.45), "glow", f"halo{k}_w", rot=r, shade=False))
        els.append(el((8 + rr - 0.45, ring_y, 8 - rr + 0.45), (8 + rr, ring_y + th, 8 + rr - 0.45), "glow", f"halo{k}_e", rot=r, shade=False))
    return {
        "texture_size": [64, 64],
        "textures": {"0": f"{NS}:item/blade_storm_knife", "particle": f"{NS}:item/blade_storm_knife"},
        "elements": els,
        "display": {
            "gui": {"rotation": [25, -35, -45], "translation": [0, -0.5, 0], "scale": [1.15, 1.15, 1.15]},
            "ground": {"rotation": [0, 0, 0], "translation": [0, 1.0, 0], "scale": [1.0, 1.0, 1.0]},
            "fixed": {"rotation": [0, 90, -45], "translation": [0, 0, 0], "scale": [1.2, 1.2, 1.2]},
            "head": {"rotation": [0, 0, 0], "translation": [0, 8, 0], "scale": [1.0, 1.0, 1.0]},
            "thirdperson_righthand": {"rotation": [0, -90, 55], "translation": [0, 2.0, 1.0], "scale": [0.85, 0.85, 0.85]},
            "thirdperson_lefthand": {"rotation": [0, 90, -55], "translation": [0, 2.0, 1.0], "scale": [0.85, 0.85, 0.85]},
            "firstperson_righthand": {"rotation": [0, -90, 25], "translation": [1.1, 2.6, 1.1], "scale": [0.7, 0.7, 0.7]},
            "firstperson_lefthand": {"rotation": [0, 90, -25], "translation": [1.1, 2.6, 1.1], "scale": [0.7, 0.7, 0.7]},
        },
    }


def flat(frm, to, tex_faces, name, rot=None):
    """Cuboide quase plano com textura inteira nas duas faces grandes."""
    full = [0, 0, 16, 16]
    e = {"name": name, "from": [round(v, 3) for v in frm], "to": [round(v, 3) for v in to],
         "shade": False, "faces": {f: {"uv": full, "texture": "#0"} for f in tex_faces}}
    if rot:
        e["rotation"] = {"angle": rot[0], "axis": rot[1], "origin": list(rot[2])}
    return e


def fx_model(tex, elements):
    return {"texture_size": [64, 64] if "smoke" in tex else [32, 32],
            "textures": {"0": f"{NS}:item/fx/{tex}", "particle": f"{NS}:item/fx/{tex}"},
            "elements": elements}


def sphere_shell(tex_v, tex_h, base_radius=8.0):
    """
    'Esfera' feita de discos cruzados com textura circular: 8 planos verticais (a cada 22,5 graus)
    + 5 planos horizontais com raio de calota esferica. Visto de qualquer angulo, le-se como uma bola
    de fumaca volumetrica; girar a entidade faz a fumaca 'rodar'.
    """
    els = []
    c = 8.0
    R = base_radius
    t = 0.05
    for i, ang in enumerate((-45.0, -22.5, 0.0, 22.5, 45.0)):
        z = c + i * 0.012
        els.append(flat((c - R, c - R, z - t), (c + R, c + R, z + t), ("north", "south"), f"vx_{i}",
                        rot=(ang, "y", (c, c, c))))
    for i, ang in enumerate((-22.5, 0.0, 22.5)):
        x = c + 0.03 + i * 0.012
        els.append(flat((x - t, c - R, c - R), (x + t, c + R, c + R), ("east", "west"), f"vz_{i}",
                        rot=(ang, "y", (c, c, c))))
    for i, h in enumerate((-5.0, -2.5, 0.0, 2.5, 5.0)):
        rr = math.sqrt(max(0.5, R * R - h * h))
        y = c + h + i * 0.01
        els.append(flat((c - rr, y - t, c - rr), (c + rr, y + t, c + rr), ("up", "down"), f"h_{i}",
                        rot=((22.5 if i % 2 else 0.0), "y", (c, y, c))))
    return els


def wind_ring_elements():
    c = 8.0
    return [
        flat((0, c - 0.1, 0), (16, c + 0.1, 16), ("up", "down"), "ring_a"),
        flat((0, c + 0.45, 0), (16, c + 0.65, 16), ("up", "down"), "ring_b", rot=(22.5, "y", (c, c, c))),
        flat((0, c - 0.65, 0), (16, c - 0.45, 16), ("up", "down"), "ring_c", rot=(-22.5, "y", (c, c, c))),
    ]


def wind_tunnel_elements():
    """Tunel de vento ao longo do eixo Y (frente = +Y): aneis que alargam para tras + paineis de corrente."""
    els = []
    c = 8.0
    ring_angles = (0.0, 22.5, 45.0, -22.5, -45.0, 0.0)
    for i in range(6):
        y = 1.5 + i * 2.6                      # i=0 atras, i=5 frente
        half = 8.0 - i * 0.9                   # alargado atras, fino na frente
        els.append(flat((c - half, y, c - half), (c + half, y + 0.15, c + half), ("up", "down"), f"ring_{i}",
                        rot=(ring_angles[i], "y", (c, y, c))))
    for i, (cx, cz, plane) in enumerate(((c + 6.2, c, "zy"), (c - 6.2, c, "zy"), (c, c + 6.2, "xy"), (c, c - 6.2, "xy"))):
        if plane == "zy":
            els.append(flat((cx - 0.05, 0.5, cz - 2.6), (cx + 0.05, 15.5, cz + 2.6), ("east", "west"), f"panel_{i}"))
        else:
            els.append(flat((cx - 2.6, 0.5, cz - 0.05), (cx + 2.6, 15.5, cz + 0.05), ("north", "south"), f"panel_{i}"))
    return els


def wind_spiral_elements():
    """Dupla helice de 'parcelas de ar' que sobem: cubinhos + rastros verticais (sem rotacao de elemento)."""
    els = []
    c = 8.0
    n = 34
    for strand in range(2):
        for i in range(n):
            t = i / (n - 1.0)
            ang = t * math.pi * 2.0 * 2.25 + strand * math.pi
            r = 5.8 - 1.2 * t + 0.8 * strand
            x = c + r * math.cos(ang)
            z = c + r * math.sin(ang)
            y = 0.8 + t * 14.4
            s = 0.55 + 0.75 * (1.0 - t) * (0.6 + 0.4 * strand)
            h = s * 2.4
            faces = ("north", "south", "east", "west", "up", "down")
            els.append(flat((x - s / 2, y - h / 2, z - s / 2), (x + s / 2, y + h / 2, z + s / 2), faces,
                            f"p{strand}_{i}"))
    return els

# ======================================================================== escrita e validacao

def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


def item_def(name, model=None):
    return {"model": {"type": "minecraft:model", "model": f"{NS}:item/{model or name}"}}


def generate():
    w, h, px = knife_texture()
    base.write_png(os.path.join(TEX_DIR, "blade_storm_knife.png"), w, h, px)
    write_json(os.path.join(MODEL_DIR, "blade_storm_knife.json"), knife_model())

    textures = {
        "smoke_outer_v": smoke_texture(11, (238, 246, 252), (150, 178, 196), 1.0),
        "smoke_outer_h": smoke_texture(23, (238, 246, 252), (150, 178, 196), 1.0),
        "smoke_inner_v": smoke_texture(37, (205, 224, 236), (96, 120, 138), 1.15),
        "smoke_inner_h": smoke_texture(41, (205, 224, 236), (96, 120, 138), 1.15),
        "smoke_orb_v": smoke_texture(53, (255, 255, 255), (110, 215, 245), 1.2, edge_start=0.7),
        "smoke_orb_h": smoke_texture(59, (255, 255, 255), (110, 215, 245), 1.2, edge_start=0.7),
        "wind_ring": ring_texture(7),
        "wind_streak": streak_texture(13),
        "wind_puff": puff_texture(29),
    }
    for name, (tw, th, tpx) in textures.items():
        base.write_png(os.path.join(FX_TEX_DIR, name + ".png"), tw, th, tpx)

    def shell(tag):
        # os discos verticais usam a textura _v; os horizontais usam _h (via 2 modelos combinados por elemento)
        els = sphere_shell(None, None)
        return els

    def shell_model(prefix):
        els = sphere_shell(None, None)
        model = {
            "texture_size": [64, 64],
            "textures": {"0": f"{NS}:item/fx/{prefix}_v", "1": f"{NS}:item/fx/{prefix}_h",
                         "particle": f"{NS}:item/fx/{prefix}_v"},
            "elements": els,
        }
        for e in els:
            if e["name"].startswith("h_"):
                for f in e["faces"].values():
                    f["texture"] = "#1"
        return model

    models = {
        "cloud_shell_outer": shell_model("smoke_outer"),
        "cloud_shell_inner": shell_model("smoke_inner"),
        "cloud_orb": shell_model("smoke_orb"),
        "wind_ring": fx_model("wind_ring", wind_ring_elements()),
        "wind_tunnel": None,
        "wind_spiral": fx_model("wind_puff", wind_spiral_elements()),
    }
    # tunel: aneis usam wind_ring (#0), paineis usam wind_streak (#1)
    tun = fx_model("wind_ring", wind_tunnel_elements())
    tun["textures"]["1"] = f"{NS}:item/fx/wind_streak"
    for e in tun["elements"]:
        if e["name"].startswith("panel_"):
            for f in e["faces"].values():
                f["texture"] = "#1"
    models["wind_tunnel"] = tun

    for name, m in models.items():
        write_json(os.path.join(MODEL_DIR, name + ".json"), m)
        write_json(os.path.join(ITEM_DIR, name + ".json"), item_def(name))

    # item segurado/inventario: usa o modelo 3D da faca (antes era um sprite plano)
    write_json(os.path.join(ITEM_DIR, "blade_storm.json"), item_def("blade_storm", "blade_storm_knife"))
    write_json(os.path.join(ITEM_DIR, "blade_storm_knife.json"), item_def("blade_storm_knife"))


def check():
    errors = []
    names = ["blade_storm_knife", "cloud_shell_outer", "cloud_shell_inner", "cloud_orb",
             "wind_ring", "wind_tunnel", "wind_spiral"]
    total = 0
    for name in names:
        path = os.path.join(MODEL_DIR, name + ".json")
        try:
            m = json.load(open(path, encoding="utf-8"))
        except Exception as ex:  # noqa: BLE001
            errors.append(f"{name}: JSON invalido ({ex})")
            continue
        els = m.get("elements", [])
        total += len(els)
        for key, ref in m["textures"].items():
            tpath = os.path.join(ASSETS, "textures", ref.split(":", 1)[1] + ".png")
            if not os.path.exists(tpath):
                errors.append(f"{name}: textura ausente {tpath}")
        for e in els:
            for v in e["from"] + e["to"]:
                if not -16.0 <= v <= 32.0:
                    errors.append(f"{name}/{e['name']}: coordenada fora de -16..32 ({v})")
            for a, b in zip(e["from"], e["to"]):
                if b < a:
                    errors.append(f"{name}/{e['name']}: to < from")
            r = e.get("rotation")
            if r and (r["angle"] not in ALLOWED_ANGLES or r["axis"] not in ("x", "y", "z")):
                errors.append(f"{name}/{e['name']}: rotacao invalida {r}")
            for fn, f in e["faces"].items():
                if any(not 0.0 <= u <= 16.0 for u in f["uv"]):
                    errors.append(f"{name}/{e['name']}/{fn}: UV fora de 0..16 {f['uv']}")
                if f["texture"].lstrip("#") not in m["textures"]:
                    errors.append(f"{name}/{e['name']}/{fn}: textura {f['texture']} nao declarada")
        if not os.path.exists(os.path.join(ITEM_DIR, name + ".json")):
            errors.append(f"{name}: items/{name}.json ausente")
        print(f"  {name:20s} {len(els):3d} elementos")
    if errors:
        print("ERROS:")
        for e in errors:
            print("  -", e)
        return 1
    print(f"OK: {len(names)} modelos, {total} elementos, UVs/rotacoes/texturas validados.")
    return 0


if __name__ == "__main__":
    if "--check" not in sys.argv:
        generate()
        print("Assets FX gerados.")
    sys.exit(check())
