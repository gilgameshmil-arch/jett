#!/usr/bin/env python3
"""
Gera os assets procedurais (placeholders originais) da etapa 1:

  - textures/item/blade_storm_knife.png  (64x64, atlas: metade esquerda = cabo, direita = lâmina de energia)
  - textures/item/blade_storm.png        (64x64, ícone do item: leque de 5 lâminas)
  - models/item/blade_storm_knife.json   (modelo 3D feito de cubóides)

Usa apenas a biblioteca padrão do Python. Para trocar por arte final, basta
substituir os PNGs/JSON no mesmo caminho (ou editar o modelo no Blockbench).

Uso:  python3 tools/generate_assets.py
"""
import json
import math
import os
import struct
import zlib

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.normpath(os.path.join(HERE, "..", "src", "main", "resources", "assets", "valorantmod"))

# ---------------------------------------------------------------- PNG utils

def write_png(path, w, h, px):
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        for x in range(w):
            r, g, b, a = px[y][x]
            raw += bytes((r, g, b, a))

    def chunk(tag, data):
        body = struct.pack(">I", len(data)) + tag + data
        return body + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    png = (b"\x89PNG\r\n\x1a\n"
           + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(bytes(raw), 9))
           + chunk(b"IEND", b""))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(png)


def lerp(a, b, t):
    return a + (b - a) * t


def lerp_col(c1, c2, t):
    t = max(0.0, min(1.0, t))
    return tuple(int(round(lerp(c1[i], c2[i], t))) for i in range(3))


# ---------------------------------------------------------------- paleta (original, inspirada em "vento e energia")
WHITE = (255, 255, 255)
CYAN = (127, 227, 255)
TEAL = (30, 156, 184)
DEEP = (12, 90, 112)
STEEL = (27, 32, 40)
STEEL_HI = (52, 62, 74)
RED = (255, 70, 85)
NAVY = (11, 26, 36)

# ---------------------------------------------------------------- textura da faca (atlas 64x64)

def knife_texture():
    W = H = 64
    px = [[(0, 0, 0, 0) for _ in range(W)] for _ in range(H)]
    for y in range(H):
        for x in range(W):
            if x < 32:
                # --- cabo (v = (16 - y_mundo) * 4): pomo 58..64, empunhadura 44..58, guarda 40..44
                if y >= 58:
                    c = lerp_col(STEEL_HI, STEEL, (y - 58) / 6.0)
                    if 59 <= y <= 60:
                        c = RED
                elif y >= 44:
                    band = (y // 3) % 2
                    c = STEEL_HI if band == 0 else STEEL
                    if x % 8 == 0:
                        c = lerp_col(c, CYAN, 0.25)
                elif y >= 40:
                    c = lerp_col(CYAN, TEAL, (y - 40) / 4.0)
                else:
                    c = STEEL
                px[y][x] = (c[0], c[1], c[2], 255)
            else:
                # --- lâmina de energia: gradiente vertical + núcleo brilhante central
                if y < 12:
                    c = lerp_col(WHITE, CYAN, y / 12.0)
                elif y < 40:
                    c = lerp_col(CYAN, TEAL, (y - 12) / 28.0)
                else:
                    c = lerp_col(TEAL, DEEP, (y - 40) / 24.0)
                du = (x - 47.5)
                glow = math.exp(-(du / 3.2) ** 2)
                c = lerp_col(c, WHITE, glow * 0.85)
                # veios horizontais sutis (aparência de energia)
                if (y + x) % 9 == 0:
                    c = lerp_col(c, WHITE, 0.25)
                px[y][x] = (c[0], c[1], c[2], 255)
    return W, H, px

# ---------------------------------------------------------------- ícone do item (leque de 5 lâminas)

def point_in_poly(x, y, poly):
    inside = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi + 1e-12) + xi:
            inside = not inside
        j = i
    return inside


def blend(dst, src, alpha):
    a = alpha
    da = dst[3] / 255.0
    out_a = a + da * (1 - a)
    if out_a <= 0:
        return (0, 0, 0, 0)
    r = (src[0] * a + dst[0] * da * (1 - a)) / out_a
    g = (src[1] * a + dst[1] * da * (1 - a)) / out_a
    b = (src[2] * a + dst[2] * da * (1 - a)) / out_a
    return (int(r), int(g), int(b), int(out_a * 255))


def draw_poly(px, poly, color_fn, ss=3):
    W = len(px[0])
    H = len(px)
    xs = [p[0] for p in poly]
    ys = [p[1] for p in poly]
    x0, x1 = max(0, int(min(xs)) - 1), min(W - 1, int(max(xs)) + 1)
    y0, y1 = max(0, int(min(ys)) - 1), min(H - 1, int(max(ys)) + 1)
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            hit = 0
            for sy in range(ss):
                for sx in range(ss):
                    if point_in_poly(x + (sx + 0.5) / ss, y + (sy + 0.5) / ss, poly):
                        hit += 1
            if hit:
                cov = hit / float(ss * ss)
                col = color_fn(x + 0.5, y + 0.5)
                px[y][x] = blend(px[y][x], col, cov)


def rot(pts, ang_deg, pivot):
    a = math.radians(ang_deg)
    ca, sa = math.cos(a), math.sin(a)
    return [(pivot[0] + x * ca - y * sa, pivot[1] + x * sa + y * ca) for x, y in pts]


def icon_texture():
    W = H = 64
    px = [[(0, 0, 0, 0) for _ in range(W)] for _ in range(H)]
    pivot = (32, 50)
    blade = [(0, -48), (5, -20), (3.5, 4), (0, 9), (-3.5, 4), (-5, -20)]
    guard = [(-8, 4), (8, 4), (8, 8), (-8, 8)]
    grip = [(-2.2, 8), (2.2, 8), (2.2, 14), (-2.2, 14)]

    def outline(p, k):
        return [(x * k, y * k) for x, y in p]

    for ang in (-34, 34, -17, 17, 0):
        # contorno escuro
        draw_poly(px, rot(outline(blade, 1.18), ang, pivot), lambda x, y: (*NAVY, 255))
        draw_poly(px, rot(outline(guard, 1.15), ang, pivot), lambda x, y: (*NAVY, 255))
        draw_poly(px, rot(outline(grip, 1.2), ang, pivot), lambda x, y: (*NAVY, 255))
        # corpo
        def blade_col(x, y, ang=ang):
            t = (50 - y) / 48.0 if ang == 0 else (y - 2) / 50.0
            t = max(0.0, min(1.0, t))
            return (*lerp_col(WHITE, TEAL, 1 - t if ang == 0 else t), 255)

        def blade_grad(x, y, ang=ang):
            # gradiente ao longo do comprimento da lâmina (ponta branca -> base turquesa)
            dy = y - pivot[1]
            dx = x - pivot[0]
            a = math.radians(-ang)
            ly = dx * math.sin(a) + dy * math.cos(a)  # y local
            t = (ly + 48.0) / 57.0
            return (*lerp_col(WHITE, TEAL, max(0.0, min(1.0, t))), 255)

        draw_poly(px, rot(blade, ang, pivot), blade_grad)
        draw_poly(px, rot(guard, ang, pivot), lambda x, y: (*RED, 255))
        draw_poly(px, rot(grip, ang, pivot), lambda x, y: (*STEEL_HI, 255))
    return W, H, px

# ---------------------------------------------------------------- modelo 3D da faca (cubóides)

def element(frm, to, region, shade=True, name=""):
    (x0, y0, z0), (x1, y1, z1) = frm, to
    base = 0 if region == "handle" else 32

    def u(v):
        return round(base + v * 2.0, 3)

    def v_(y):
        return round((16.0 - y) * 4.0, 3)

    side_uv = [u(x0), v_(y1), u(x1), v_(y0)]
    end_uv = [u(z0), v_(y1), u(z1), v_(y0)]
    top_uv = [u(x0), 0, u(x1), 2]
    bot_uv = [u(x0), 62, u(x1), 64]
    el = {
        "name": name,
        "from": [x0, y0, z0],
        "to": [x1, y1, z1],
        "faces": {
            "north": {"uv": side_uv, "texture": "#0"},
            "south": {"uv": side_uv, "texture": "#0"},
            "east": {"uv": end_uv, "texture": "#0"},
            "west": {"uv": end_uv, "texture": "#0"},
            "up": {"uv": top_uv, "texture": "#0"},
            "down": {"uv": bot_uv, "texture": "#0"},
        },
    }
    if not shade:
        el["shade"] = False
    return el


def knife_model():
    els = [
        # cabo
        element((6.4, 0.0, 7.0), (9.6, 1.5, 9.0), "handle", name="pommel"),
        element((7.2, 1.5, 7.2), (8.8, 5.0, 8.8), "handle", name="grip"),
        element((5.0, 5.0, 7.0), (11.0, 6.0, 9.0), "handle", name="guard"),
        # lâmina (afunila até a ponta) - sem sombreamento para parecer luminosa
        element((6.4, 6.0, 7.4), (9.6, 9.0, 8.6), "blade", shade=False, name="blade_1"),
        element((6.8, 9.0, 7.5), (9.2, 12.0, 8.5), "blade", shade=False, name="blade_2"),
        element((7.2, 12.0, 7.6), (8.8, 14.5, 8.4), "blade", shade=False, name="blade_3"),
        element((7.7, 14.5, 7.8), (8.3, 16.0, 8.2), "blade", shade=False, name="tip"),
        # aleta de energia transversal (dá volume de "vento" em torno da lâmina)
        element((7.5, 6.5, 6.6), (8.5, 12.5, 9.4), "blade", shade=False, name="energy_fin"),
    ]
    return {
        "texture_size": [64, 64],
        "textures": {
            "0": "valorantmod:item/blade_storm_knife",
            "particle": "valorantmod:item/blade_storm_knife",
        },
        "elements": els,
        "display": {
            "gui": {"rotation": [0, 0, -45], "translation": [0, 0, 0], "scale": [1.0, 1.0, 1.0]},
            "ground": {"rotation": [0, 0, -45], "translation": [0, 4, 0], "scale": [1.0, 1.0, 1.0]},
            "fixed": {"rotation": [0, 0, -45], "translation": [0, 0, 0], "scale": [1.0, 1.0, 1.0]},
            "thirdperson_righthand": {"rotation": [0, 0, 0], "translation": [0, 3, 1], "scale": [0.85, 0.85, 0.85]},
            "firstperson_righthand": {"rotation": [0, 0, 0], "translation": [0, 4, 0], "scale": [0.85, 0.85, 0.85]},
        },
    }


def main():
    w, h, px = knife_texture()
    write_png(os.path.join(ASSETS, "textures", "item", "blade_storm_knife.png"), w, h, px)

    w, h, px = icon_texture()
    write_png(os.path.join(ASSETS, "textures", "item", "blade_storm.png"), w, h, px)

    model_path = os.path.join(ASSETS, "models", "item", "blade_storm_knife.json")
    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    with open(model_path, "w", encoding="utf-8") as f:
        json.dump(knife_model(), f, indent=2)
        f.write("\n")
    print("Assets gerados em", ASSETS)


if __name__ == "__main__":
    main()
