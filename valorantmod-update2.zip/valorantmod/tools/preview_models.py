#!/usr/bin/env python3
"""
Pre-visualizacao aproximada dos modelos (projecao ortografica, cor media por face).
NAO e o renderizador do Minecraft: serve para conferir forma/proporcao antes de abrir o jogo.

Uso: python3 tools/preview_models.py <modelo> <saida.png> [yaw] [pitch]
Ex.: python3 tools/preview_models.py blade_storm_knife /tmp/knife.png 35 20
"""
import json
import math
import os
import sys

from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.normpath(os.path.join(HERE, "..", "src", "main", "resources", "assets", "valorantmod"))


def rot3(p, yaw, pitch):
    x, y, z = p
    cy, sy = math.cos(yaw), math.sin(yaw)
    x, z = x * cy + z * sy, -x * sy + z * cy
    cp, sp = math.cos(pitch), math.sin(pitch)
    y, z = y * cp - z * sp, y * sp + z * cp
    return x, y, z


def elem_rot(p, r):
    a = math.radians(r["angle"])
    o = r["origin"]
    x, y, z = p[0] - o[0], p[1] - o[1], p[2] - o[2]
    c, s = math.cos(a), math.sin(a)
    if r["axis"] == "y":
        x, z = x * c + z * s, -x * s + z * c
    elif r["axis"] == "x":
        y, z = y * c - z * s, y * s + z * c
    else:
        x, y = x * c - y * s, x * s + y * c
    return x + o[0], y + o[1], z + o[2]


FACES = {
    "north": [(0, 1, 0), (1, 1, 0), (1, 0, 0), (0, 0, 0)],
    "south": [(1, 1, 1), (0, 1, 1), (0, 0, 1), (1, 0, 1)],
    "west": [(0, 1, 1), (0, 1, 0), (0, 0, 0), (0, 0, 1)],
    "east": [(1, 1, 0), (1, 1, 1), (1, 0, 1), (1, 0, 0)],
    "up": [(0, 1, 1), (1, 1, 1), (1, 1, 0), (0, 1, 0)],
    "down": [(0, 0, 0), (1, 0, 0), (1, 0, 1), (0, 0, 1)],
}


def avg_color(img, uv):
    w, h = img.size
    x0, y0, x1, y1 = [int(round(v / 16.0 * (w if i % 2 == 0 else h))) for i, v in enumerate(uv)]
    x0, x1 = sorted((x0, x1))
    y0, y1 = sorted((y0, y1))
    x1 = max(x1, x0 + 1)
    y1 = max(y1, y0 + 1)
    box = img.crop((x0, y0, min(w, x1), min(h, y1))).convert("RGBA")
    px = list(box.get_flattened_data()) if hasattr(box, "get_flattened_data") else list(box.getdata())
    n = len(px)
    if n == 0:
        return (0, 0, 0, 0)
    a = sum(p[3] for p in px) / n
    if a == 0:
        return (0, 0, 0, 0)
    r = sum(p[0] * p[3] for p in px) / (n * a)
    g = sum(p[1] * p[3] for p in px) / (n * a)
    b = sum(p[2] * p[3] for p in px) / (n * a)
    return (int(r), int(g), int(b), int(a))


def main():
    name, out = sys.argv[1], sys.argv[2]
    yaw = math.radians(float(sys.argv[3]) if len(sys.argv) > 3 else 35)
    pitch = math.radians(float(sys.argv[4]) if len(sys.argv) > 4 else 20)
    model = json.load(open(os.path.join(ASSETS, "models", "item", name + ".json")))
    texs = {}
    for k, ref in model["textures"].items():
        texs[k] = Image.open(os.path.join(ASSETS, "textures", ref.split(":", 1)[1] + ".png")).convert("RGBA")

    polys = []
    for e in model["elements"]:
        f, t = e["from"], e["to"]
        for fname, face in e["faces"].items():
            pts = []
            for cx, cy, cz in FACES[fname]:
                p = (t[0] if cx else f[0], t[1] if cy else f[1], t[2] if cz else f[2])
                if "rotation" in e:
                    p = elem_rot(p, e["rotation"])
                pts.append(rot3((p[0] - 8, p[1] - 8, p[2] - 8), yaw, pitch))
            depth = sum(p[2] for p in pts) / 4.0
            tex = texs[face["texture"].lstrip("#")]
            col = avg_color(tex, face["uv"])
            polys.append((depth, pts, col, tex, face["uv"]))
    polys.sort(key=lambda p: p[0])

    S, scale = 640, 34
    img = Image.new("RGBA", (S, S), (28, 32, 40, 255))
    layer = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    for depth, pts, col, tex, uv in polys:
        if col[3] == 0:
            continue
        xy = [(S / 2 + p[0] * scale, S / 2 - p[1] * scale) for p in pts]
        # mapeamento afim textura -> tela (ortografico: face e um paralelogramo)
        w, h = tex.size
        u0, v0, u1, v1 = [uv[0] / 16.0 * w, uv[1] / 16.0 * h, uv[2] / 16.0 * w, uv[3] / 16.0 * h]
        cw, ch = max(1.0, abs(u1 - u0)), max(1.0, abs(v1 - v0))
        crop = tex.crop((int(min(u0, u1)), int(min(v0, v1)), int(min(u0, u1) + cw), int(min(v0, v1) + ch)))
        ex, ey = (xy[1][0] - xy[0][0], xy[1][1] - xy[0][1])
        fx, fy = (xy[3][0] - xy[0][0], xy[3][1] - xy[0][1])
        det = ex * fy - ey * fx
        if abs(det) < 1e-6:
            continue
        # fonte (a,b) = M^-1 * (dest - P0); s = fonte_u/cw, t = fonte_v/ch
        ia, ib = fy / det, -fx / det
        ic, id_ = -ey / det, ex / det
        sx, sy = crop.size
        coeffs = (ia * sx, ib * sx, -(ia * xy[0][0] + ib * xy[0][1]) * sx,
                  ic * sy, id_ * sy, -(ic * xy[0][0] + id_ * xy[0][1]) * sy)
        tmp = crop.transform((S, S), Image.AFFINE, coeffs, resample=Image.NEAREST)
        mask = Image.new("L", (S, S), 0)
        ImageDraw.Draw(mask).polygon(xy, fill=255)
        tmp.putalpha(Image.composite(tmp.getchannel("A"), Image.new("L", (S, S), 0), mask))
        layer = Image.alpha_composite(layer, tmp)
    img = Image.alpha_composite(img, layer)
    img.save(out)
    print("salvo", out)


if __name__ == "__main__":
    main()
